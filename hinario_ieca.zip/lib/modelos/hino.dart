class Hino {
  /// Número árabe do hino (usado para ordenação e para as telas
  /// que só trabalham com números inteiros).
  ///
  /// Quando o hino tem numeração romana (ex: "I", "II"), este
  /// campo fica a 0 e o valor original é guardado em [numeroTexto].
  final int numero;

  /// Valor original do número, em texto.
  ///
  /// - Se o hino for numerado em árabe (ex: "1", "2"), este campo
  ///   fica a `null`.
  /// - Se o hino for numerado em romano (ex: "I", "II"), este campo
  ///   guarda o texto original para ser exibido.
  final String? numeroTexto;

  final String titulo;
  final String idioma;
  final String categoria;
  final List<String> estrofes;
  final String? coro;

  Hino({
    required this.numero,
    this.numeroTexto,
    required this.titulo,
    required this.idioma,
    required this.categoria,
    required this.estrofes,
    this.coro,
  });

  // =============================================================
  // GETTER DE CONVENIÊNCIA
  // =============================================================

  /// Texto do número para exibição.
  /// Se o hino tem numeração romana, devolve o texto original.
  /// Caso contrário, devolve o número árabe em texto.
  String get numeroExibicao =>
      numeroTexto ?? numero.toString();

  // =============================================================
  // FROM JSON
  // =============================================================

  factory Hino.fromJson(Map<String, dynamic> json) {
    // -----------------------------------------------------------
    // NÚMERO
    // -----------------------------------------------------------
    //
    // Aceita tanto números árabes ("1", "2", "10")
    // como números romanos ("I", "II", "XVII").
    //
    // - Se for árabe → guarda em `numero` (int).
    // - Se for romano → guarda em `numeroTexto` (String).
    // - Se falhar tudo → `numero` = 0, `numeroTexto` = null.
    //

    final String numeroRaw =
        json['numero']?.toString().trim() ?? '';

    final int? numeroArabico =
        int.tryParse(numeroRaw);

    final int numero = numeroArabico ?? 0;

    final String? numeroTexto =
        numeroArabico == null && numeroRaw.isNotEmpty
            ? numeroRaw
            : null;

    // -----------------------------------------------------------
    // TÍTULO
    // -----------------------------------------------------------

    final String titulo =
        json['titulo_pt']?.toString().trim() ?? '';

    // -----------------------------------------------------------
    // TEXTO
    // -----------------------------------------------------------

    final String texto =
        json['texto_pt']?.toString() ?? '';

    // -----------------------------------------------------------
    // CORO
    // -----------------------------------------------------------

    final String? coroBruto =
        json['coro']?.toString().trim();

    final String? coro =
        (coroBruto == null ||
                coroBruto.isEmpty ||
                coroBruto == 'null')
            ? null
            : coroBruto;

    // -----------------------------------------------------------
    // ESTROFES
    // -----------------------------------------------------------

    final List<String> estrofes = texto
        .split(RegExp(r'\n\s*\n'))
        .map((estrofe) => estrofe.trim())
        .where((estrofe) => estrofe.isNotEmpty)
        .toList();

    // -----------------------------------------------------------
    // IDIOMA
    // -----------------------------------------------------------

    const String idioma = 'Português';

    // -----------------------------------------------------------
    // CATEGORIA
    // -----------------------------------------------------------

    final String categoria =
        json['categoria']?.toString().trim() ?? '';

    // -----------------------------------------------------------
    // RETORNO
    // -----------------------------------------------------------

    return Hino(
      numero: numero,
      numeroTexto: numeroTexto,
      titulo: titulo,
      idioma: idioma,
      categoria: categoria,
      estrofes: estrofes,
      coro: coro,
    );
  }
}