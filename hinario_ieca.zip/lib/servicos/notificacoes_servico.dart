import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../app/app.dart';
import '../modelos/missao_ieca.dart';
import '../modelos/versiculo.dart';
import '../telas/informacoes_ieca/leitura_missao_ieca_tela.dart';
import 'informacoes_ieca_servico.dart';
import 'palavra_do_dia_servico.dart';
import 'servico_hinos.dart';

/// ===============================================================
/// SERVIÇO DE NOTIFICAÇÕES DO HINÁRIO IECA
/// ===============================================================
///
/// Responsável por:
///
/// - inicializar as notificações locais;
/// - configurar permissões;
/// - agendar Bom Dia;
/// - agendar Palavra do Dia;
/// - agendar Hino do Dia;
/// - agendar Boa Noite;
/// - agendar "Sabias que?";
/// - enviar notificações iniciais;
/// - processar notificações que abriram a aplicação.
///
/// IMPORTANTE:
///
/// O serviço foi estruturado para não refazer todo o trabalho em
/// cada abertura da aplicação.
///
/// As notificações diárias são mantidas numa janela de 30 dias.
/// A janela só é renovada quando faltarem 7 dias ou menos.
///
/// O mesmo princípio é aplicado ao "Sabias que?".
///
/// ===============================================================
class NotificacoesServico {
  static final NotificacoesServico instancia =
      NotificacoesServico._interno();

  NotificacoesServico._interno();

  final FlutterLocalNotificationsPlugin _notificacoes =
      FlutterLocalNotificationsPlugin();

  Uint8List? _logoIecaBytes;

  bool _inicializado = false;

  /// Evita que duas partes da aplicação inicializem o serviço
  /// simultaneamente.
  Future<void>? _inicializacaoEmAndamento;

  // =============================================================
  // IDS
  // =============================================================

  static const int idHinoDoDia = 1001;

  static const int _idTesteBomDia = 9001;
  static const int _idTestePalavra = 9002;
  static const int _idTesteHino = 9003;
  static const int _idTesteNoite = 9004;
  static const int _idTesteSabiasQue = 9005;

  static const int _idPalavraInicialInstalacao = 6001;
  static const int _idHinoInicialInstalacao = 6002;

  static const int _baseIdManha = 100000;
  static const int _baseIdPalavra = 200000;
  static const int _baseIdHino = 300000;
  static const int _baseIdNoite = 400000;
  static const int _baseIdSabiasQue = 500000;

  // =============================================================
  // CHAVES DE PREFERÊNCIAS
  // =============================================================

  static const String _chaveNotificacoesIniciaisEnviadas =
      'notificacoes_iniciais_enviadas';

  static const String _chaveNotificacoesAgendadasAte =
      'notificacoes_agendadas_ate';

  static const String _chavePermissoesSolicitadas =
      'notificacoes_permissoes_solicitadas';

  static const String _chaveSabiasQuePeriodoNotificado =
      'sabias_que_periodo_notificado';

  static const String _chaveSabiasQuePeriodoAgendadoAte =
      'sabias_que_periodo_agendado_ate';

  // =============================================================
  // CONFIGURAÇÃO
  // =============================================================

  static const int diasAgendados = 30;

  static const int diasMargemRenovacao = 7;

  static const int ciclosSabiasQueAgendados = 4;

  static const int atrasoPrimeiroSabiasQueEmMinutos = 5;

  static const int horaManha = 6;
  static const int minutoManha = 0;

  static const int atrasoPalavra = 1;
  static const int atrasoHino = 2;

  static const int horaNoite = 21;
  static const int minutoNoite = 0;

  // =============================================================
  // CANAIS
  // =============================================================

  static const String canalBomDia = 'ieca_bom_dia';

  static const String canalPalavraDia = 'ieca_palavra_dia';

  static const String canalHinoDia = 'ieca_hino_dia';

  static const String canalBoaNoite = 'ieca_boa_noite';

  static const String canalSabiasQue = 'ieca_sabias_que';

  static const String nomeCanalBomDia = 'Bom Dia — IECA';

  static const String descricaoCanalBomDia =
      'Mensagem de Bom Dia do Hinário IECA.';

  static const String nomeCanalPalavraDia =
      'Palavra do Dia — IECA';

  static const String descricaoCanalPalavraDia =
      'Palavra do Dia do Hinário IECA.';

  static const String nomeCanalHinoDia =
      'Hino do Dia — IECA';

  static const String descricaoCanalHinoDia =
      'Hino do Dia do Hinário IECA.';

  static const String nomeCanalBoaNoite =
      'Boa Noite — IECA';

  static const String descricaoCanalBoaNoite =
      'Mensagem de Boa Noite do Hinário IECA.';

  static const String nomeCanalSabiasQue =
      'Sabias que? — IECA';

  static const String descricaoCanalSabiasQue =
      'Curiosidades sobre a história, missão e presença da IECA.';

  /// Ícone usado nas notificações Android.
  static const String _iconeNotificacaoAndroid =
      '@mipmap/ic_launcher';

  // =============================================================
  // INICIALIZAÇÃO
  // =============================================================

  Future<void> inicializar() async {
    if (_inicializado) {
      debugPrint('   ⚠️ inicializar() já foi feito antes. A ignorar.');
      return;
    }

    if (_inicializacaoEmAndamento != null) {
      await _inicializacaoEmAndamento;
      return;
    }

    final Future<void> inicializacao = _inicializarInternamente();

    _inicializacaoEmAndamento = inicializacao;

    try {
      await inicializacao;
    } finally {
      if (identical(_inicializacaoEmAndamento, inicializacao)) {
        _inicializacaoEmAndamento = null;
      }
    }
  }

  Future<void> _inicializarInternamente() async {
    if (_inicializado) return;

    if (kIsWeb) {
      debugPrint(
        '   ⚠️ kIsWeb = true → inicializar() ignorado '
        '(web não suporta notificações locais).',
      );
      _inicializado = true;
      return;
    }

    debugPrint('   🔧 A inicializar plugin de notificações...');

    // -----------------------------------------------------------
    // FUSOS HORÁRIOS
    // -----------------------------------------------------------

    tz.initializeTimeZones();

    try {
      final TimezoneInfo timezoneInfo =
          await FlutterTimezone.getLocalTimezone();

      tz.setLocalLocation(
        tz.getLocation(timezoneInfo.identifier),
      );
    } catch (e) {
      tz.setLocalLocation(
        tz.getLocation('UTC'),
      );

      debugPrint(
        'Não foi possível obter o fuso horário local: $e',
      );
    }

    // -----------------------------------------------------------
    // CONFIGURAÇÃO DO PLUGIN
    // -----------------------------------------------------------

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings(
      _iconeNotificacaoAndroid,
    );

    const DarwinInitializationSettings darwinSettings =
        DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const InitializationSettings settings =
        InitializationSettings(
      android: androidSettings,
      iOS: darwinSettings,
      macOS: darwinSettings,
    );

    await _notificacoes.initialize(
      settings: settings,
      onDidReceiveNotificationResponse:
          _aoClicarNaNotificacao,
    );

    // -----------------------------------------------------------
    // LOGO
    // -----------------------------------------------------------

    await _carregarLogoIeca();

    _inicializado = true;

    debugPrint(
      'Notificações IECA inicializadas.',
    );
  }

  Future<Uint8List?> _carregarLogoIeca() async {
    if (_logoIecaBytes != null) {
      return _logoIecaBytes;
    }

    try {
      final ByteData dados =
          await rootBundle.load(
        'assets/images/logoieca.png',
      );

      _logoIecaBytes = dados.buffer.asUint8List(
        dados.offsetInBytes,
        dados.lengthInBytes,
      );

      debugPrint(
        'Logo IECA carregado para as notificações.',
      );

      return _logoIecaBytes;
    } catch (e) {
      debugPrint(
        'Não foi possível carregar o logo IECA: $e',
      );

      return null;
    }
  }

  // =============================================================
  // ESTADO REAL DAS NOTIFICAÇÕES
  // =============================================================

  Future<bool> _notificacoesAndroidAtivadas() async {
    if (kIsWeb) return false;

    final AndroidFlutterLocalNotificationsPlugin?
        androidPlugin =
        _notificacoes
            .resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>();

    if (androidPlugin == null) {
      return false;
    }

    try {
      final bool ativadas =
          await androidPlugin.areNotificationsEnabled() ??
              false;

      debugPrint(
        'Permissão real de notificações Android: '
        '${ativadas ? 'ATIVADA' : 'DESATIVADA'}.',
      );

      return ativadas;
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao consultar a permissão real do Android: $e',
      );

      debugPrint('$stackTrace');

      return false;
    }
  }

  /// Consulta o Android apenas quando realmente precisamos
  /// verificar ou reconstruir os agendamentos.
  Future<List<PendingNotificationRequest>>
      _obterNotificacoesPendentes() async {
    try {
      final List<PendingNotificationRequest> pendentes =
          await _notificacoes.pendingNotificationRequests();

      debugPrint(
        'Notificações realmente pendentes: '
        '${pendentes.length}.',
      );

      return pendentes;
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao consultar notificações pendentes: $e',
      );

      debugPrint('$stackTrace');

      return <PendingNotificationRequest>[];
    }
  }

  Future<Set<int>> _obterIdsPendentes() async {
    final List<PendingNotificationRequest> pendentes =
        await _obterNotificacoesPendentes();

    return pendentes
        .map((PendingNotificationRequest n) => n.id)
        .toSet();
  }

  // =============================================================
  // TOQUE NAS NOTIFICAÇÕES
  // =============================================================

  void _aoClicarNaNotificacao(
    NotificationResponse resposta,
  ) {
    final String? payload = resposta.payload;

    debugPrint(
      'Notificação seleccionada: $payload',
    );

    if (payload == null || payload.isEmpty) {
      return;
    }

    _processarPayload(payload);
  }

  Future<void> _processarPayload(
    String payload,
  ) async {
    final List<String> partes = payload.split('|');

    if (partes.isEmpty) {
      return;
    }

    final String tipo = partes.first.trim();

    switch (tipo) {
      case 'sabias_que':
        if (partes.length < 2) {
          return;
        }

        final String id = partes[1].trim();

        if (id.isEmpty) {
          return;
        }

        await _abrirMissaoPorId(id);
        break;

      default:
        debugPrint(
          'Payload sem ação de navegação: $payload',
        );
        break;
    }
  }

  Future<void> _abrirMissaoPorId(
    String id,
  ) async {
    final MissaoIeca? missao =
        await InformacoesIecaServico.instancia
            .obterMissaoPorId(id);

    if (missao == null) {
      debugPrint(
        'Missão não encontrada para o payload: $id',
      );

      return;
    }

    for (int tentativa = 0; tentativa < 30; tentativa++) {
      final NavigatorState? navigator =
          navigatorKey.currentState;

      if (navigator != null) {
        navigator.push(
          MaterialPageRoute<void>(
            builder: (_) => LeituraMissaoIecaTela(
              missao: missao,
            ),
          ),
        );

        debugPrint(
          'Missão aberta através da notificação: '
          '${missao.id}',
        );

        return;
      }

      await Future<void>.delayed(
        const Duration(milliseconds: 100),
      );
    }

    debugPrint(
      'Não foi possível encontrar o NavigatorState '
      'para abrir a missão: $id',
    );
  }

  // =============================================================
  // NOTIFICAÇÃO QUE ABRIU A APLICAÇÃO
  // =============================================================

  Future<void> processarNotificacaoQueAbriuAplicacao() async {
    await inicializar();

    if (kIsWeb) {
      debugPrint(
        '   ⚠️ kIsWeb = true → notificação de arranque ignorada.',
      );
      return;
    }

    try {
      final NotificationAppLaunchDetails? detalhes =
          await _notificacoes.getNotificationAppLaunchDetails();

      if (detalhes == null ||
          !detalhes.didNotificationLaunchApp) {
        return;
      }

      final String? payload =
          detalhes.notificationResponse?.payload;

      if (payload == null || payload.isEmpty) {
        return;
      }

      debugPrint(
        'Aplicação aberta através de notificação: $payload',
      );

      await _processarPayload(payload);
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao processar notificação que abriu '
        'a aplicação: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  // =============================================================
  // PERMISSÕES
  // =============================================================

  Future<void> solicitarPermissaoAndroid() async {
    if (kIsWeb) {
      return;
    }

    final AndroidFlutterLocalNotificationsPlugin?
        androidPlugin =
        _notificacoes
            .resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>();

    if (androidPlugin == null) {
      debugPrint(
        'Plugin Android de notificações não disponível.',
      );

      return;
    }

    try {
      final bool ativadas =
          await androidPlugin.areNotificationsEnabled() ??
              false;

      if (ativadas) {
        debugPrint(
          'Permissão Android já está ativa.',
        );

        return;
      }

      debugPrint(
        'Permissão Android desativada. '
        'Solicitando autorização...',
      );

      final bool? concedida =
          await androidPlugin.requestNotificationsPermission();

      debugPrint(
        'Resultado do pedido de permissão Android: '
        '${concedida == true ? 'concedida' : 'não concedida'}.',
      );

      final bool estadoFinal =
          await androidPlugin.areNotificationsEnabled() ??
              false;

      debugPrint(
        'Estado final da permissão Android: '
        '${estadoFinal ? 'ATIVADA' : 'DESATIVADA'}.',
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao solicitar permissões Android: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  Future<void> solicitarPermissaoIOS() async {
    if (kIsWeb) {
      return;
    }

    final IOSFlutterLocalNotificationsPlugin?
        iosPlugin =
        _notificacoes
            .resolvePlatformSpecificImplementation<
                IOSFlutterLocalNotificationsPlugin>();

    if (iosPlugin == null) {
      return;
    }

    try {
      final bool? concedida =
          await iosPlugin.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );

      debugPrint(
        'Permissão de notificações iOS: '
        '${concedida == true ? 'concedida' : 'não concedida'}.',
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao solicitar permissões iOS: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  Future<void> solicitarPermissoes() async {
    await inicializar();

    if (kIsWeb) {
      debugPrint('   ⚠️ kIsWeb = true → permissões ignoradas.');
      return;
    }

    debugPrint('   🔧 A solicitar permissões...');

    try {
      debugPrint(
        'Verificando permissões reais de notificações...',
      );

      await solicitarPermissaoAndroid();
      await solicitarPermissaoIOS();

      final bool androidAtivo =
          await _notificacoesAndroidAtivadas();

      final SharedPreferences prefs =
          await SharedPreferences.getInstance();

      await prefs.setBool(
        _chavePermissoesSolicitadas,
        true,
      );

      debugPrint(
        'Processamento das permissões concluído. '
        'Android ativo: $androidAtivo.',
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao processar permissões de notificações: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  // =============================================================
  // DETALHES DAS NOTIFICAÇÕES
  // =============================================================

  Future<NotificationDetails>
      _criarDetalhesNotificacao({
    required String corpo,
    required String canalId,
    required String nomeCanal,
    required String descricaoCanal,
  }) async {
    final Uint8List? logoBytes =
        await _carregarLogoIeca();

    ByteArrayAndroidBitmap? largeIcon;

    if (logoBytes != null) {
      largeIcon = ByteArrayAndroidBitmap(
        logoBytes,
      );
    }

    return NotificationDetails(
      android: AndroidNotificationDetails(
        canalId,
        nomeCanal,
        channelDescription: descricaoCanal,
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        enableVibration: true,
        icon: _iconeNotificacaoAndroid,
        largeIcon: largeIcon,
        styleInformation: BigTextStyleInformation(
          corpo,
        ),
      ),
      iOS: const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      ),
    );
  }

  Future<void> mostrarNotificacao({
    required String titulo,
    required String corpo,
    String? payload,
    int? id,
    required String canalId,
    required String nomeCanal,
    required String descricaoCanal,
  }) async {
    await inicializar();

    if (kIsWeb) {
      debugPrint(
        '   ⚠️ kIsWeb = true → mostrarNotificacao ignorada.',
      );
      return;
    }

    final bool androidAtivo =
        await _notificacoesAndroidAtivadas();

    if (!androidAtivo) {
      debugPrint(
        'Notificação não mostrada porque a permissão '
        'do Android está desativada.',
      );

      return;
    }

    try {
      final NotificationDetails detalhes =
          await _criarDetalhesNotificacao(
        corpo: corpo,
        canalId: canalId,
        nomeCanal: nomeCanal,
        descricaoCanal: descricaoCanal,
      );

      await _notificacoes.show(
        id: id ?? _idTesteBomDia,
        title: titulo,
        body: corpo,
        notificationDetails: detalhes,
        payload: payload,
      );

      debugPrint(
        'Notificação imediata apresentada. '
        'ID: ${id ?? _idTesteBomDia}.',
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao mostrar notificação imediata '
        'ID ${id ?? _idTesteBomDia}: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  Future<bool> _agendarNotificacao({
    required int id,
    required String titulo,
    required String corpo,
    required tz.TZDateTime dataHora,
    String? payload,
    required String canalId,
    required String nomeCanal,
    required String descricaoCanal,
  }) async {
    try {
      final NotificationDetails detalhes =
          await _criarDetalhesNotificacao(
        corpo: corpo,
        canalId: canalId,
        nomeCanal: nomeCanal,
        descricaoCanal: descricaoCanal,
      );

      await _notificacoes.zonedSchedule(
        id: id,
        title: titulo,
        body: corpo,
        notificationDetails: detalhes,
        scheduledDate: dataHora,
        androidScheduleMode:
            AndroidScheduleMode.exactAllowWhileIdle,
        payload: payload,
      );

      return true;
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao agendar notificação ID $id '
        'para $dataHora: $e',
      );

      debugPrint('$stackTrace');

      return false;
    }
  }

  // =============================================================
  // MENSAGENS
  // =============================================================

  String _mensagemBomDia() {
    return '''
Que a paz do Senhor esteja contigo neste novo dia.

Que Deus ilumine os teus caminhos,
fortaleça a tua fé e encha o teu coração
de esperança.

Tenha um dia abençoado! 🙏
''';
  }

  String _mensagemPalavra({
    required String referencia,
    required String texto,
  }) {
    return '''
📖 Palavra do Dia

$referencia

$texto

Que a Palavra de Deus fortaleça a tua vida. 🙏
''';
  }

  String _mensagemHino({
    required String hino,
  }) {
    return '''
🎵 Hino do Dia

$hino

Que este hino seja uma expressão de louvor
e gratidão a Deus. 🙏
''';
  }

  String _mensagemNoite() {
    return '''
Entregue a Deus tudo aquilo que aconteceu hoje.

Descanse o seu coração, pois o Senhor continua
cuidando de você.

Que a paz de Cristo esteja contigo durante esta noite.

Durma em paz e Deus te abençoe. 🙏
''';
  }

  String _mensagemSabiasQue({
    required MissaoIeca missao,
  }) {
    return '''
${missao.curiosidade}

Descobre mais sobre a IECA no aplicativo.
''';
  }

  // =============================================================
  // HINO / PALAVRA
  // =============================================================

  Future<String?> _obterHinoParaData(
    DateTime data,
  ) async {
    final hino =
        await ServicoHinos().obterHinoParaData(data);

    if (hino == null) {
      debugPrint(
        'Hino não encontrado para a data: '
        '${data.year}-${data.month}-${data.day}',
      );

      return null;
    }

    return 'Hino ${hino.numero} — ${hino.titulo}';
  }

  Future<Versiculo?> _obterPalavraParaData(
    DateTime data,
  ) async {
    final Versiculo? palavra =
        await PalavraDoDiaServico.obterPalavraParaData(
      data,
    );

    if (palavra == null) {
      debugPrint(
        'Palavra do Dia não encontrada para a data: '
        '${data.year}-${data.month}-${data.day}',
      );

      return null;
    }

    return palavra;
  }

  // =============================================================
  // IDS E DATAS
  // =============================================================

  int _idParaData(
    DateTime data,
    int base,
  ) {
    final DateTime inicio =
        DateTime(2000, 1, 1);

    final DateTime dataNorm =
        DateTime(
      data.year,
      data.month,
      data.day,
    );

    return base +
        dataNorm.difference(inicio).inDays;
  }

  int _idParaPeriodoSabiasQue(
    int periodo,
  ) {
    return _baseIdSabiasQue + periodo;
  }

  DateTime _normalizarData(
    DateTime data,
  ) {
    return DateTime(
      data.year,
      data.month,
      data.day,
    );
  }

  String _dataParaString(
    DateTime data,
  ) {
    final String ano =
        data.year.toString().padLeft(4, '0');

    final String mes =
        data.month.toString().padLeft(2, '0');

    final String dia =
        data.day.toString().padLeft(2, '0');

    return '$ano-$mes-$dia';
  }

  DateTime? _stringParaData(
    String? valor,
  ) {
    if (valor == null || valor.isEmpty) {
      return null;
    }

    try {
      return DateTime.parse(valor);
    } catch (_) {
      return null;
    }
  }

  // =============================================================
  // NOTIFICAÇÕES INICIAIS
  // =============================================================

  Future<void> enviarNotificacoesIniciais() async {
    await inicializar();

    if (kIsWeb) {
      debugPrint(
        '   ⚠️ kIsWeb = true → notificações iniciais ignoradas.',
      );
      return;
    }

    debugPrint('   🔧 A verificar notificações iniciais...');

    try {
      if (!await _notificacoesAndroidAtivadas()) {
        debugPrint(
          'Notificações iniciais não enviadas: '
          'permissão Android desativada.',
        );

        return;
      }

      final SharedPreferences prefs =
          await SharedPreferences.getInstance();

      final bool jaEnviadas =
          prefs.getBool(
                _chaveNotificacoesIniciaisEnviadas,
              ) ??
              false;

      if (jaEnviadas) {
        return;
      }

      final DateTime agora =
          DateTime.now();

      final Versiculo? palavra =
          await _obterPalavraParaData(agora);

      if (palavra != null) {
        await mostrarNotificacao(
          id: _idPalavraInicialInstalacao,
          titulo: 'Palavra do Dia 📖',
          corpo: _mensagemPalavra(
            referencia:
                palavra.referencia.trim(),
            texto: palavra.texto.trim(),
          ),
          payload:
              'palavra_inicial|'
              '${agora.year}-${agora.month}-${agora.day}|'
              'referencia=${palavra.referencia.trim()}',
          canalId: canalPalavraDia,
          nomeCanal: nomeCanalPalavraDia,
          descricaoCanal:
              descricaoCanalPalavraDia,
        );
      }

      final String? hino =
          await _obterHinoParaData(agora);

      if (hino != null) {
        await mostrarNotificacao(
          id: _idHinoInicialInstalacao,
          titulo: 'Hino do Dia 🎵',
          corpo: _mensagemHino(
            hino: hino,
          ),
          payload:
              'hino_inicial|'
              '${agora.year}-${agora.month}-${agora.day}|'
              '$hino',
          canalId: canalHinoDia,
          nomeCanal: nomeCanalHinoDia,
          descricaoCanal:
              descricaoCanalHinoDia,
        );
      }

      await prefs.setBool(
        _chaveNotificacoesIniciaisEnviadas,
        true,
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao enviar notificações iniciais: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  // =============================================================
  // NOTIFICAÇÕES DIÁRIAS
  // =============================================================

  Future<DateTime?> _obterDataAgendadaAte() async {
    final SharedPreferences prefs =
        await SharedPreferences.getInstance();

    return _stringParaData(
      prefs.getString(
        _chaveNotificacoesAgendadasAte,
      ),
    );
  }

  Future<void> _guardarDataAgendadaAte(
    DateTime data,
  ) async {
    final SharedPreferences prefs =
        await SharedPreferences.getInstance();

    await prefs.setString(
      _chaveNotificacoesAgendadasAte,
      _dataParaString(data),
    );
  }

  bool _precisaRenovarAgendamento(
    DateTime agora,
    DateTime? agendadoAte,
  ) {
    if (agendadoAte == null) {
      return true;
    }

    final DateTime limite =
        _normalizarData(agendadoAte);

    final DateTime hoje =
        _normalizarData(agora);

    final int diasRestantes =
        limite.difference(hoje).inDays;

    return diasRestantes <= diasMargemRenovacao;
  }

  Future<void> agendarNotificacoesDiarias({
    int dias = diasAgendados,
    int horaManhaConfigurada = horaManha,
    int minutoManhaConfigurado = minutoManha,
    int horaNoiteConfigurada = horaNoite,
    int minutoNoiteConfigurado = minutoNoite,
  }) async {
    await inicializar();

    if (kIsWeb) {
      debugPrint(
        '   ⚠️ kIsWeb = true → agendamento diário ignorado.',
      );
      return;
    }

    debugPrint('   🔧 A agendar notificações diárias...');

    try {
      if (!await _notificacoesAndroidAtivadas()) {
        debugPrint(
          'Agendamento diário interrompido: '
          'permissão Android desativada.',
        );

        return;
      }

      final DateTime hoje =
          _normalizarData(DateTime.now());

      final DateTime? agendadoAte =
          await _obterDataAgendadaAte();

      // ---------------------------------------------------------
      // OTIMIZAÇÃO PRINCIPAL
      // ---------------------------------------------------------
      //
      // Se ainda temos mais de 7 dias de notificações
      // agendadas, não consultamos o Android e não percorremos
      // os 30 dias novamente.
      //
      // Esta é a situação normal na maioria das aberturas
      // da aplicação.
      // ---------------------------------------------------------

      if (!_precisaRenovarAgendamento(
        hoje,
        agendadoAte,
      )) {
        debugPrint(
          'Agendamento diário ainda válido até '
          '${_dataParaString(agendadoAte!)}. '
          'Nenhuma renovação necessária.',
        );

        return;
      }

      debugPrint(
        'Renovação das notificações diárias necessária.',
      );

      // Só chegamos aqui quando precisamos realmente
      // verificar o estado do Android.
      final Set<int> idsPendentes =
          await _obterIdsPendentes();

      final tz.TZDateTime agoraTz =
          tz.TZDateTime.now(tz.local);

      int quantidadeAgendamentosCriados = 0;

      final DateTime ultimoDiaProcessado =
          hoje.add(
        Duration(days: dias - 1),
      );

      for (int i = 0; i < dias; i++) {
        final DateTime data =
            hoje.add(Duration(days: i));

        // -------------------------------------------------------
        // BOM DIA
        // -------------------------------------------------------

        final tz.TZDateTime dataBomDia =
            tz.TZDateTime(
          tz.local,
          data.year,
          data.month,
          data.day,
          horaManhaConfigurada,
          minutoManhaConfigurado,
        );

        final int idBomDia =
            _idParaData(
          data,
          _baseIdManha,
        );

        if (dataBomDia.isAfter(agoraTz) &&
            !idsPendentes.contains(idBomDia)) {
          final bool ok =
              await _agendarNotificacao(
            id: idBomDia,
            titulo:
                'Bom dia, querido irmão/ã! 🌅',
            corpo: _mensagemBomDia(),
            dataHora: dataBomDia,
            payload:
                'bom_dia|${_dataParaString(data)}',
            canalId: canalBomDia,
            nomeCanal: nomeCanalBomDia,
            descricaoCanal:
                descricaoCanalBomDia,
          );

          if (ok) {
            quantidadeAgendamentosCriados++;
            idsPendentes.add(idBomDia);
          }
        }

        // -------------------------------------------------------
        // PALAVRA DO DIA
        // -------------------------------------------------------

        final tz.TZDateTime dataPalavra =
            dataBomDia.add(
          const Duration(
            minutes: atrasoPalavra,
          ),
        );

        final int idPalavra =
            _idParaData(
          data,
          _baseIdPalavra,
        );

        if (dataPalavra.isAfter(agoraTz) &&
            !idsPendentes.contains(idPalavra)) {
          final Versiculo? palavra =
              await _obterPalavraParaData(data);

          if (palavra != null) {
            final bool ok =
                await _agendarNotificacao(
              id: idPalavra,
              titulo: 'Palavra do Dia 📖',
              corpo: _mensagemPalavra(
                referencia:
                    palavra.referencia.trim(),
                texto:
                    palavra.texto.trim(),
              ),
              dataHora: dataPalavra,
              payload:
                  'palavra|'
                  '${_dataParaString(data)}|'
                  'referencia=${palavra.referencia.trim()}',
              canalId: canalPalavraDia,
              nomeCanal:
                  nomeCanalPalavraDia,
              descricaoCanal:
                  descricaoCanalPalavraDia,
            );

            if (ok) {
              quantidadeAgendamentosCriados++;
              idsPendentes.add(idPalavra);
            }
          }
        }

        // -------------------------------------------------------
        // HINO DO DIA
        // -------------------------------------------------------

        final tz.TZDateTime dataHino =
            dataBomDia.add(
          const Duration(
            minutes: atrasoHino,
          ),
        );

        final int idHino =
            _idParaData(
          data,
          _baseIdHino,
        );

        if (dataHino.isAfter(agoraTz) &&
            !idsPendentes.contains(idHino)) {
          final String? hino =
              await _obterHinoParaData(data);

          if (hino != null) {
            final bool ok =
                await _agendarNotificacao(
              id: idHino,
              titulo: 'Hino do Dia 🎵',
              corpo: _mensagemHino(
                hino: hino,
              ),
              dataHora: dataHino,
              payload:
                  'hino|${_dataParaString(data)}|$hino',
              canalId: canalHinoDia,
              nomeCanal:
                  nomeCanalHinoDia,
              descricaoCanal:
                  descricaoCanalHinoDia,
            );

            if (ok) {
              quantidadeAgendamentosCriados++;
              idsPendentes.add(idHino);
            }
          }
        }

        // -------------------------------------------------------
        // BOA NOITE
        // -------------------------------------------------------

        final tz.TZDateTime dataNoite =
            tz.TZDateTime(
          tz.local,
          data.year,
          data.month,
          data.day,
          horaNoiteConfigurada,
          minutoNoiteConfigurado,
        );

        final int idNoite =
            _idParaData(
          data,
          _baseIdNoite,
        );

        if (dataNoite.isAfter(agoraTz) &&
            !idsPendentes.contains(idNoite)) {
          final bool ok =
              await _agendarNotificacao(
            id: idNoite,
            titulo:
                'Boa noite, querido irmão/ã! 🌙',
            corpo: _mensagemNoite(),
            dataHora: dataNoite,
            payload:
                'noite|${_dataParaString(data)}',
            canalId: canalBoaNoite,
            nomeCanal:
                nomeCanalBoaNoite,
            descricaoCanal:
                descricaoCanalBoaNoite,
          );

          if (ok) {
            quantidadeAgendamentosCriados++;
            idsPendentes.add(idNoite);
          }
        }
      }

      await _guardarDataAgendadaAte(
        ultimoDiaProcessado,
      );

      debugPrint(
        'Agendamento diário concluído. '
        'Novos: $quantidadeAgendamentosCriados. '
        'Janela até: '
        '${_dataParaString(ultimoDiaProcessado)}.',
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao configurar notificações diárias: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  Future<void> configurarNotificacoesDiarias() async {
    await agendarNotificacoesDiarias();
  }

  // =============================================================
  // "SABIAS QUE?"
  // =============================================================

  Future<int?> _obterPeriodoSabiasQueAgendadoAte() async {
    final SharedPreferences prefs =
        await SharedPreferences.getInstance();

    return prefs.getInt(
      _chaveSabiasQuePeriodoAgendadoAte,
    );
  }

  Future<void> _guardarPeriodoSabiasQueAgendadoAte(
    int periodo,
  ) async {
    final SharedPreferences prefs =
        await SharedPreferences.getInstance();

    await prefs.setInt(
      _chaveSabiasQuePeriodoAgendadoAte,
      periodo,
    );
  }

  Future<int?> _obterPeriodoSabiasQueNotificado() async {
    final SharedPreferences prefs =
        await SharedPreferences.getInstance();

    return prefs.getInt(
      _chaveSabiasQuePeriodoNotificado,
    );
  }

  Future<void> configurarNotificacaoSabiasQue() async {
    await inicializar();

    if (kIsWeb) {
      debugPrint(
        '   ⚠️ kIsWeb = true → Sabias que? ignorado.',
      );
      return;
    }

    debugPrint('   🔧 A configurar Sabias que?...');

    try {
      if (!await _notificacoesAndroidAtivadas()) {
        debugPrint(
          'Agendamento "Sabias que?" interrompido: '
          'permissão Android desativada.',
        );

        return;
      }

      final InformacoesIecaServico informacoes =
          InformacoesIecaServico.instancia;

      final DateTime agora =
          DateTime.now();

      final int periodoAtual =
          await informacoes.obterPeriodoAtual(
        agora: agora,
      );

      final int? periodoAgendadoAte =
          await _obterPeriodoSabiasQueAgendadoAte();

      // ---------------------------------------------------------
      // OTIMIZAÇÃO
      // ---------------------------------------------------------
      //
      // Se já temos os quatro períodos seguintes agendados,
      // não consultamos as notificações pendentes e não
      // reconstruímos a agenda.
      //
      // ---------------------------------------------------------

      final int periodoNecessarioAte =
          periodoAtual + ciclosSabiasQueAgendados;

      if (periodoAgendadoAte != null &&
          periodoAgendadoAte >= periodoNecessarioAte) {
        debugPrint(
          '"Sabias que?" já está agendado até ao '
          'período $periodoAgendadoAte. '
          'Nenhuma renovação necessária.',
        );

        return;
      }

      debugPrint(
        'Renovação de "Sabias que?" necessária.',
      );

      // Só agora consultamos o Android.
      final Set<int> idsPendentes =
          await _obterIdsPendentes();

      final DateTime inicioRotacao =
          await informacoes.obterInicioRotacao();

      final int periodo =
          periodoAtual;

      final tz.TZDateTime agoraTz =
          tz.TZDateTime.now(tz.local);

      final DateTime inicioPeriodoAtual =
          await informacoes.obterInicioPeriodo(
        agora: agora,
      );

      final MissaoIeca missaoAtual =
          await informacoes.obterMissaoAtual(
        agora: agora,
      );

      final bool ehPrimeiroPeriodo =
          periodo == 0;

      final DateTime inicioNotificacaoAtual =
          ehPrimeiroPeriodo
              ? inicioRotacao.add(
                  const Duration(
                    minutes:
                        atrasoPrimeiroSabiasQueEmMinutos,
                  ),
                )
              : inicioPeriodoAtual;

      final tz.TZDateTime dataNotificacaoAtual =
          tz.TZDateTime(
        tz.local,
        inicioNotificacaoAtual.year,
        inicioNotificacaoAtual.month,
        inicioNotificacaoAtual.day,
        inicioNotificacaoAtual.hour,
        inicioNotificacaoAtual.minute,
        inicioNotificacaoAtual.second,
      );

      final int? periodoNotificado =
          await _obterPeriodoSabiasQueNotificado();

      int maiorPeriodoAgendado =
          periodoAgendadoAte ?? -1;

      // ---------------------------------------------------------
      // PERÍODO ATUAL
      // ---------------------------------------------------------

      final int idPeriodoAtual =
          _idParaPeriodoSabiasQue(
        periodo,
      );

      final bool periodoAtualPendente =
          idsPendentes.contains(
        idPeriodoAtual,
      );

      if (!periodoAtualPendente) {
        if (dataNotificacaoAtual.isAfter(
          agoraTz,
        )) {
          final bool ok =
              await _agendarNotificacao(
            id: idPeriodoAtual,
            titulo:
                'Sabias que? — IECA',
            corpo: _mensagemSabiasQue(
              missao: missaoAtual,
            ),
            dataHora:
                dataNotificacaoAtual,
            payload:
                'sabias_que|${missaoAtual.id}',
            canalId: canalSabiasQue,
            nomeCanal:
                nomeCanalSabiasQue,
            descricaoCanal:
                descricaoCanalSabiasQue,
          );

          if (ok) {
            idsPendentes.add(
              idPeriodoAtual,
            );

            if (periodo >
                maiorPeriodoAgendado) {
              maiorPeriodoAgendado =
                  periodo;
            }
          }
        } else if (periodoNotificado !=
            periodo) {
          await mostrarNotificacao(
            id: idPeriodoAtual,
            titulo:
                'Sabias que? — IECA',
            corpo: _mensagemSabiasQue(
              missao: missaoAtual,
            ),
            payload:
                'sabias_que|${missaoAtual.id}',
            canalId: canalSabiasQue,
            nomeCanal:
                nomeCanalSabiasQue,
            descricaoCanal:
                descricaoCanalSabiasQue,
          );

          final SharedPreferences prefs =
              await SharedPreferences
                  .getInstance();

          await prefs.setInt(
            _chaveSabiasQuePeriodoNotificado,
            periodo,
          );
        }
      }

      // ---------------------------------------------------------
      // PRÓXIMOS PERÍODOS
      // ---------------------------------------------------------

      for (
        int d = 1;
        d <= ciclosSabiasQueAgendados;
        d++
      ) {
        final int periodoFuturo =
            periodoAtual + d;

        final int idPeriodo =
            _idParaPeriodoSabiasQue(
          periodoFuturo,
        );

        if (idsPendentes.contains(
          idPeriodo,
        )) {
          if (periodoFuturo >
              maiorPeriodoAgendado) {
            maiorPeriodoAgendado =
                periodoFuturo;
          }

          continue;
        }

        final DateTime inicioPeriodo =
            await informacoes
                .obterInicioPeriodoPorNumero(
          periodoFuturo,
        );

        final MissaoIeca missao =
            await informacoes.obterMissaoAtual(
          agora: inicioPeriodo,
        );

        final tz.TZDateTime dataNotificacao =
            tz.TZDateTime(
          tz.local,
          inicioPeriodo.year,
          inicioPeriodo.month,
          inicioPeriodo.day,
          inicioPeriodo.hour,
          inicioPeriodo.minute,
          inicioPeriodo.second,
        );

        if (!dataNotificacao.isAfter(
          agoraTz,
        )) {
          continue;
        }

        final bool ok =
            await _agendarNotificacao(
          id: idPeriodo,
          titulo:
              'Sabias que? — IECA',
          corpo: _mensagemSabiasQue(
            missao: missao,
          ),
          dataHora:
              dataNotificacao,
          payload:
              'sabias_que|${missao.id}',
          canalId: canalSabiasQue,
          nomeCanal:
              nomeCanalSabiasQue,
          descricaoCanal:
              descricaoCanalSabiasQue,
        );

        if (ok) {
          idsPendentes.add(
            idPeriodo,
          );

          if (periodoFuturo >
              maiorPeriodoAgendado) {
            maiorPeriodoAgendado =
                periodoFuturo;
          }
        }
      }

      await _guardarPeriodoSabiasQueAgendadoAte(
        maiorPeriodoAgendado,
      );

      debugPrint(
        '"Sabias que?" configurado até ao '
        'período $maiorPeriodoAgendado.',
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao configurar "Sabias que?": $e',
      );

      debugPrint('$stackTrace');
    }
  }

  // =============================================================
  // HINO DO DIA LEGADO
  // =============================================================

  Future<void> agendarHinoDoDia({
    required String titulo,
    required String corpo,
    int hora = 6,
    int minuto = 0,
    String? payload,
  }) async {
    await inicializar();

    if (kIsWeb) {
      return;
    }

    try {
      await _notificacoes.cancel(
        id: idHinoDoDia,
      );

      final tz.TZDateTime agora =
          tz.TZDateTime.now(tz.local);

      tz.TZDateTime proxima =
          tz.TZDateTime(
        tz.local,
        agora.year,
        agora.month,
        agora.day,
        hora,
        minuto,
      );

      if (!proxima.isAfter(agora)) {
        proxima = proxima.add(
          const Duration(days: 1),
        );
      }

      await _agendarNotificacao(
        id: idHinoDoDia,
        titulo: titulo,
        corpo: corpo,
        dataHora: proxima,
        payload: payload,
        canalId: canalHinoDia,
        nomeCanal: nomeCanalHinoDia,
        descricaoCanal:
            descricaoCanalHinoDia,
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao agendar Hino do Dia legado: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  // =============================================================
  // TESTE
  // =============================================================

  Future<void> testarNotificacao() async {
    await inicializar();

    if (kIsWeb) {
      return;
    }

    if (!await _notificacoesAndroidAtivadas()) {
      debugPrint(
        'Teste cancelado: permissão Android desativada.',
      );

      return;
    }

    try {
      await mostrarNotificacao(
        id: _idTesteBomDia,
        titulo: 'Bom Dia — IECA',
        corpo:
            'Esta é uma notificação de teste de Bom Dia.',
        payload: 'teste_bom_dia',
        canalId: canalBomDia,
        nomeCanal: nomeCanalBomDia,
        descricaoCanal:
            descricaoCanalBomDia,
      );

      await mostrarNotificacao(
        id: _idTestePalavra,
        titulo: 'Palavra do Dia',
        corpo: '''
📖 Palavra do Dia

João 3:16

Porque Deus amou o mundo de tal maneira
que deu o seu Filho unigénito.

Que a Palavra de Deus fortaleça a tua vida.
''',
        payload: 'teste_palavra',
        canalId: canalPalavraDia,
        nomeCanal: nomeCanalPalavraDia,
        descricaoCanal:
            descricaoCanalPalavraDia,
      );

      await mostrarNotificacao(
        id: _idTesteHino,
        titulo: 'Hino do Dia',
        corpo: '''
🎵 Hino do Dia

Hino 1 — Exemplo de Hino

Que este hino seja uma expressão de louvor
e gratidão a Deus.
''',
        payload: 'teste_hino',
        canalId: canalHinoDia,
        nomeCanal: nomeCanalHinoDia,
        descricaoCanal:
            descricaoCanalHinoDia,
      );

      await mostrarNotificacao(
        id: _idTesteNoite,
        titulo: 'Boa Noite — IECA',
        corpo:
            'Esta é uma notificação de teste de Boa Noite.',
        payload: 'teste_boa_noite',
        canalId: canalBoaNoite,
        nomeCanal: nomeCanalBoaNoite,
        descricaoCanal:
            descricaoCanalBoaNoite,
      );

      final MissaoIeca missao =
          await InformacoesIecaServico
              .instancia
              .obterMissaoAtual();

      await mostrarNotificacao(
        id: _idTesteSabiasQue,
        titulo: 'Sabias que? — IECA',
        corpo: _mensagemSabiasQue(
          missao: missao,
        ),
        payload:
            'sabias_que|${missao.id}',
        canalId: canalSabiasQue,
        nomeCanal: nomeCanalSabiasQue,
        descricaoCanal:
            descricaoCanalSabiasQue,
      );

      debugPrint(
        'Notificações de teste enviadas.',
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao executar teste de notificações: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  // =============================================================
  // CANCELAMENTOS
  // =============================================================

  Future<void> cancelarNotificacoesDiarias() async {
    await inicializar();

    if (kIsWeb) {
      return;
    }

    try {
      final List<PendingNotificationRequest>
          pendentes =
          await _obterNotificacoesPendentes();

      final List<int> idsDiarios =
          pendentes
              .where(
                (n) =>
                    n.id >= _baseIdManha &&
                    n.id < _baseIdSabiasQue,
              )
              .map(
                (n) => n.id,
              )
              .toList();

      for (final int id in idsDiarios) {
        await _notificacoes.cancel(
          id: id,
        );
      }

      final SharedPreferences prefs =
          await SharedPreferences.getInstance();

      await prefs.remove(
        _chaveNotificacoesAgendadasAte,
      );

      debugPrint(
        'Notificações diárias canceladas: '
        '${idsDiarios.length}.',
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao cancelar notificações diárias: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  Future<void> cancelarHinoDoDia() async {
    await inicializar();

    if (kIsWeb) {
      return;
    }

    try {
      await _notificacoes.cancel(
        id: idHinoDoDia,
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao cancelar Hino do Dia legado: $e',
      );

      debugPrint('$stackTrace');
    }
  }

  Future<void> cancelarTodas() async {
    await inicializar();

    if (kIsWeb) {
      return;
    }

    try {
      await _notificacoes.cancelAll();

      final SharedPreferences prefs =
          await SharedPreferences.getInstance();

      await prefs.remove(
        _chaveNotificacoesAgendadasAte,
      );

      await prefs.remove(
        _chaveSabiasQuePeriodoNotificado,
      );

      await prefs.remove(
        _chaveSabiasQuePeriodoAgendadoAte,
      );

      debugPrint(
        'Todas as notificações foram canceladas.',
      );
    } catch (e, stackTrace) {
      debugPrint(
        'Erro ao cancelar todas as notificações: $e',
      );

      debugPrint('$stackTrace');
    }
  }
}