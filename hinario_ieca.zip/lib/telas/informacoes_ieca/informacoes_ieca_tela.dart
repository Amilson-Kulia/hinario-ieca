import 'package:flutter/material.dart';

import '../../app/tema.dart';
import '../../componentes/cabecalho_ieca.dart';
import '../../componentes/navegacao_inferior_ieca.dart';
import '../../modelos/historia_ieca.dart';
import '../../modelos/missao_ieca.dart';
import '../../servicos/informacoes_ieca_servico.dart';
import '../biblia/biblia_tela.dart';
import '../hinario/idiomas_tela.dart';
import '../home/home_tela.dart';
import '../sobre/sobre_tela.dart';
import 'leitura_historia_ieca_tela.dart';
import 'leitura_missao_ieca_tela.dart';

class InformacoesIecaTela extends StatefulWidget {
  const InformacoesIecaTela({super.key});

  @override
  State<InformacoesIecaTela> createState() =>
      _InformacoesIecaTelaState();
}

class _InformacoesIecaTelaState
    extends State<InformacoesIecaTela> {
  final InformacoesIecaServico _servico =
      InformacoesIecaServico.instancia;

  late Future<_DadosInformacoes> _dadosFuture;

  @override
  void initState() {
    super.initState();

    _dadosFuture = _carregarDados();
  }

  Future<_DadosInformacoes> _carregarDados() async {
    final HistoriaIeca historia =
        await _servico.carregarHistoria();

    final MissaoIeca missaoAtual =
        await _servico.obterMissaoAtual();

    final List<MissaoIeca> todasMissoes =
        await _servico.carregarMissoes();

    return _DadosInformacoes(
      historia: historia,
      missaoAtual: missaoAtual,
      todasMissoes: todasMissoes,
    );
  }

  void _recarregar() {
    setState(() {
      _dadosFuture = _carregarDados();
    });
  }

  // =========================================================
  // NAVEGAÇÃO
  // =========================================================

  void _navegar(int indice) {
    Widget destino;

    switch (indice) {
      case 0:
        destino = const HomeTela();
        break;

      case 1:
        destino = const IdiomasTela();
        break;

      case 2:
        destino = const BibliaTela();
        break;

      case 3:
        return;

      case 4:
        destino = const SobreTela();
        break;

      default:
        return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute<void>(
        builder: (_) => destino,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TemaHinario.corSuperficie,

      // =====================================================
      // CABEÇALHO
      // =====================================================

      appBar: const CabecalhoIeca(
        titulo: 'IECA',
      ),

      // =====================================================
      // CONTEÚDO
      // =====================================================

      body: FutureBuilder<_DadosInformacoes>(
        future: _dadosFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState ==
              ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (snapshot.hasError) {
            return _ErroInformacoes(
              onTentarNovamente: _recarregar,
            );
          }

          final _DadosInformacoes? dados = snapshot.data;

          if (dados == null) {
            return _ErroInformacoes(
              onTentarNovamente: _recarregar,
            );
          }

          return RefreshIndicator(
            color: TemaHinario.corPrimaria,
            onRefresh: () async {
              _recarregar();
              await _dadosFuture;
            },
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(
                20,
                20,
                20,
                32,
              ),
              children: [
                // =================================================
                // INTRODUÇÃO
                // =================================================

                const _CabecalhoInformacoes(),

                const SizedBox(height: 28),

                // =================================================
                // SECÇÃO HISTÓRIA
                // =================================================

                const _SecaoCabecalho(
                  titulo: 'Conheça a IECA',
                  subtitulo: 'História e raízes',
                  icone: Icons.auto_stories_rounded,
                ),

                const SizedBox(height: 14),

                _CardHistoria(
                  titulo: dados.historia.titulo,
                  resumo: dados.historia.resumo,
                  onLerMais: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) =>
                            LeituraHistoriaIecaTela(
                          historia: dados.historia,
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 30),

                // =================================================
                // CURIOSIDADE ROTATIVA
                // =================================================

                const _SecaoCabecalho(
                  titulo: 'Sabias que?',
                  subtitulo: 'Curiosidades da IECA',
                  icone: Icons.lightbulb_outline_rounded,
                ),

                const SizedBox(height: 14),

                _CardCuriosidade(
                  missao: dados.missaoAtual,
                  onLerMais: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) =>
                            LeituraMissaoIecaTela(
                          missao: dados.missaoAtual,
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 30),

                // =================================================
                // CARROSSEL — TODAS AS MISSÕES
                // =================================================

                const _SecaoCabecalho(
                  titulo: 'Mais sobre a IECA',
                  subtitulo: 'Navegue por todas as informações',
                  icone: Icons.explore_rounded,
                ),

                const SizedBox(height: 14),

                _CarrosselMissoes(
                  missoes: dados.todasMissoes,
                  onLerMais: (missao) {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) =>
                            LeituraMissaoIecaTela(
                          missao: missao,
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 28),

                // =================================================
                // FRASE FINAL
                // =================================================

                const _RodapeInformacoes(),
              ],
            ),
          );
        },
      ),

      // =========================================================
      // RODAPÉ / NAVEGAÇÃO
      // =========================================================

      bottomNavigationBar: NavegacaoInferiorIeca(
        indiceSelecionado: 3,
        onDestinationSelected: _navegar,
      ),
    );
  }
}

// =============================================================
// DADOS
// =============================================================

class _DadosInformacoes {
  final HistoriaIeca historia;
  final MissaoIeca missaoAtual;
  final List<MissaoIeca> todasMissoes;

  const _DadosInformacoes({
    required this.historia,
    required this.missaoAtual,
    required this.todasMissoes,
  });
}

// =============================================================
// CABEÇALHO INTERNO
// =============================================================

class _CabecalhoInformacoes extends StatelessWidget {
  const _CabecalhoInformacoes();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            TemaHinario.corPrimaria,
            const Color(0xFF6A001A),
          ],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: TemaHinario.corPrimaria.withValues(
              alpha: 0.22,
            ),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: -20,
            bottom: -20,
            child: Icon(
              Icons.church_rounded,
              size: 140,
              color: Colors.white.withValues(alpha: 0.08),
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.16),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  alignment: Alignment.center,
                  child: const Icon(
                    Icons.church_rounded,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  'A nossa Igreja',
                  style: TextStyle(
                    fontSize: 26,
                    height: 1.15,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Conhece melhor a IECA, a sua história, '
                  'a sua missão e as suas raízes em Angola.',
                  style: TextStyle(
                    fontSize: 14,
                    height: 1.5,
                    fontWeight: FontWeight.w500,
                    color: Colors.white.withValues(alpha: 0.90),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================
// CABEÇALHO DE SECÇÃO
// =============================================================

class _SecaoCabecalho extends StatelessWidget {
  final String titulo;
  final String subtitulo;
  final IconData icone;

  const _SecaoCabecalho({
    required this.titulo,
    required this.subtitulo,
    required this.icone,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: TemaHinario.corPrimaria.withValues(
              alpha: 0.10,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          alignment: Alignment.center,
          child: Icon(
            icone,
            size: 20,
            color: TemaHinario.corPrimaria,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                titulo,
                style: const TextStyle(
                  fontSize: 19,
                  height: 1.2,
                  fontWeight: FontWeight.w800,
                  color: TemaHinario.corTexto,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                subtitulo,
                style: const TextStyle(
                  fontSize: 12.5,
                  height: 1.3,
                  fontWeight: FontWeight.w500,
                  color: TemaHinario.corTextoSecundario,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// =============================================================
// CARD HISTÓRIA
// =============================================================

class _CardHistoria extends StatelessWidget {
  final String titulo;
  final String resumo;
  final VoidCallback onLerMais;

  const _CardHistoria({
    required this.titulo,
    required this.resumo,
    required this.onLerMais,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onLerMais,
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: TemaHinario.corSuperficieAlta,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: TemaHinario.corPrimaria.withValues(
                alpha: 0.14,
              ),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: TemaHinario.corPrimaria.withValues(
                  alpha: 0.06,
                ),
                blurRadius: 14,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          TemaHinario.corPrimaria,
                          const Color(0xFF6A001A),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: TemaHinario.corPrimaria.withValues(
                            alpha: 0.22,
                          ),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child: const Icon(
                      Icons.menu_book_rounded,
                      color: Colors.white,
                      size: 26,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Text(
                      titulo,
                      style: const TextStyle(
                        fontSize: 17,
                        height: 1.3,
                        fontWeight: FontWeight.w800,
                        color: TemaHinario.corTexto,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              Text(
                resumo,
                maxLines: 5,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 14,
                  height: 1.55,
                  fontWeight: FontWeight.w500,
                  color: TemaHinario.corTextoSecundario,
                ),
              ),

              const SizedBox(height: 16),

              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    'Ler mais',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: TemaHinario.corPrimaria,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Icon(
                    Icons.arrow_forward_rounded,
                    size: 18,
                    color: TemaHinario.corPrimaria,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// =============================================================
// CARD CURIOSIDADE
// =============================================================

class _CardCuriosidade extends StatelessWidget {
  final MissaoIeca missao;
  final VoidCallback onLerMais;

  const _CardCuriosidade({
    required this.missao,
    required this.onLerMais,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onLerMais,
        child: Container(
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                TemaHinario.corPrimaria,
                const Color(0xFF6A001A),
              ],
            ),
            borderRadius: BorderRadius.circular(22),
            boxShadow: [
              BoxShadow(
                color: TemaHinario.corPrimaria.withValues(
                  alpha: 0.25,
                ),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (missao.imagem != null)
                Stack(
                  children: [
                    Image.asset(
                      missao.imagem!,
                      width: double.infinity,
                      height: 200,
                      fit: BoxFit.cover,
                      errorBuilder: (
                        context,
                        error,
                        stackTrace,
                      ) {
                        return const SizedBox.shrink();
                      },
                    ),
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.transparent,
                              TemaHinario.corPrimaria.withValues(
                                alpha: 0.65,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

              Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(
                              alpha: 0.16,
                            ),
                            borderRadius:
                                BorderRadius.circular(13),
                          ),
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.lightbulb_outline_rounded,
                            color: Colors.white,
                            size: 23,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'SABIAS QUE?',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.9,
                              color: Colors.white.withValues(
                                alpha: 0.92,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 18),

                    Text(
                      missao.titulo,
                      style: const TextStyle(
                        fontSize: 20,
                        height: 1.25,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                      ),
                    ),

                    const SizedBox(height: 12),

                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 7,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(
                          alpha: 0.14,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.location_on_outlined,
                            color: Colors.white70,
                            size: 16,
                          ),
                          const SizedBox(width: 6),
                          Flexible(
                            child: Text(
                              missao.localizacao,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    Text(
                      missao.curiosidade,
                      style: TextStyle(
                        fontSize: 14.5,
                        height: 1.6,
                        fontWeight: FontWeight.w500,
                        color: Colors.white.withValues(
                          alpha: 0.94,
                        ),
                      ),
                    ),

                    const SizedBox(height: 18),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          'Ler mais',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: Colors.white.withValues(
                              alpha: 0.95,
                            ),
                          ),
                        ),
                        const SizedBox(width: 4),
                        Icon(
                          Icons.arrow_forward_rounded,
                          size: 18,
                          color: Colors.white.withValues(
                            alpha: 0.95,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// =============================================================
// CARROSSEL DE MISSÕES
// =============================================================

class _CarrosselMissoes extends StatefulWidget {
  final List<MissaoIeca> missoes;
  final ValueChanged<MissaoIeca> onLerMais;

  const _CarrosselMissoes({
    required this.missoes,
    required this.onLerMais,
  });

  @override
  State<_CarrosselMissoes> createState() =>
      _CarrosselMissoesState();
}

class _CarrosselMissoesState extends State<_CarrosselMissoes> {
  late PageController _pageController;
  int _indiceAtual = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: 0);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  bool get _temAnterior => _indiceAtual > 0;
  bool get _temProximo =>
      _indiceAtual < widget.missoes.length - 1;

  void _anterior() {
    if (!_temAnterior) return;
    _pageController.animateToPage(
      _indiceAtual - 1,
      duration: const Duration(milliseconds: 320),
      curve: Curves.easeInOutCubic,
    );
  }

  void _proximo() {
    if (!_temProximo) return;
    _pageController.animateToPage(
      _indiceAtual + 1,
      duration: const Duration(milliseconds: 320),
      curve: Curves.easeInOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.missoes.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      children: [
        // =====================================================
        // PAGEVIEW COM OS CARTÕES
        // =====================================================

        SizedBox(
          height: 320,
          child: PageView.builder(
            controller: _pageController,
            onPageChanged: (indice) {
              setState(() => _indiceAtual = indice);
            },
            itemCount: widget.missoes.length,
            itemBuilder: (context, index) {
              final missao = widget.missoes[index];

              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2),
                child: _CardMissaoCarrossel(
                  missao: missao,
                  onLerMais: () => widget.onLerMais(missao),
                ),
              );
            },
          ),
        ),

        const SizedBox(height: 14),

        // =====================================================
        // BARRA DE NAVEGAÇÃO
        // =====================================================

        _BarraNavegacaoCarrossel(
          indiceAtual: _indiceAtual,
          total: widget.missoes.length,
          temAnterior: _temAnterior,
          temProximo: _temProximo,
          onAnterior: _anterior,
          onProximo: _proximo,
        ),
      ],
    );
  }
}

// =============================================================
// CARD DE MISSÃO NO CARROSSEL
// =============================================================

class _CardMissaoCarrossel extends StatelessWidget {
  final MissaoIeca missao;
  final VoidCallback onLerMais;

  const _CardMissaoCarrossel({
    required this.missao,
    required this.onLerMais,
  });

 @override
Widget build(BuildContext context) {
  final temImagem =
      missao.imagem != null && missao.imagem!.isNotEmpty;

  return Material(
    color: Colors.transparent,
    child: InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onLerMais,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: TemaHinario.corSuperficieAlta,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: TemaHinario.corPrimaria.withValues(
              alpha: 0.14,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: TemaHinario.corPrimaria.withValues(
                alpha: 0.06,
              ),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          // ⚠️ IMPORTANTE: mainAxisSize.min evita que a Column
          // tente expandir-se para preencher altura infinita
          mainAxisSize: MainAxisSize.min,
          children: [
            // =================================================
            // IMAGEM (opcional)
            // =================================================

            if (temImagem)
              Stack(
                children: [
                  Image.asset(
                    missao.imagem!,
                    width: double.infinity,
                    height: 110,
                    fit: BoxFit.cover,
                    errorBuilder: (
                      context,
                      error,
                      stackTrace,
                    ) {
                      return const SizedBox.shrink();
                    },
                  ),
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Colors.black.withValues(alpha: 0.35),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 10,
                    left: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: TemaHinario.corPrimaria.withValues(
                          alpha: 0.92,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        missao.tipo.toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.9,
                        ),
                      ),
                    ),
                  ),
                ],
              )
            else
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 0),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: TemaHinario.corPrimaria.withValues(
                      alpha: 0.10,
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    missao.tipo.toUpperCase(),
                    style: const TextStyle(
                      color: TemaHinario.corPrimaria,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.9,
                    ),
                  ),
                ),
              ),

            // =================================================
            // CONTEÚDO — com scroll interno para nunca estourar
            // =================================================

            Flexible(
              fit: FlexFit.loose,
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // TÍTULO
                    Text(
                      missao.titulo,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 16,
                        height: 1.25,
                        fontWeight: FontWeight.w800,
                        color: TemaHinario.corTexto,
                      ),
                    ),

                    const SizedBox(height: 8),

                    // METADADOS
                    Row(
                      children: [
                        Expanded(
                          child: Row(
                            children: [
                              const Icon(
                                Icons.location_on_outlined,
                                size: 14,
                                color: TemaHinario
                                    .corTextoSecundario,
                              ),
                              const SizedBox(width: 4),
                              Flexible(
                                child: Text(
                                  missao.localizacao,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: TemaHinario
                                        .corTextoSecundario,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (missao.anoFundacao != null) ...[
                          const SizedBox(width: 10),
                          Row(
                            children: [
                              const Icon(
                                Icons.calendar_today_outlined,
                                size: 13,
                                color: TemaHinario
                                    .corTextoSecundario,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '${missao.anoFundacao}',
                                style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: TemaHinario
                                      .corTextoSecundario,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),

                    const SizedBox(height: 10),

                    // RESUMO
                    Text(
                      missao.resumo,
                      style: const TextStyle(
                        fontSize: 13,
                        height: 1.5,
                        fontWeight: FontWeight.w500,
                        color: TemaHinario.corTextoSecundario,
                      ),
                    ),

                    const SizedBox(height: 12),

                    // LER MAIS
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          'Ler mais',
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: TemaHinario.corPrimaria,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Icon(
                          Icons.arrow_forward_rounded,
                          size: 16,
                          color: TemaHinario.corPrimaria,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
}

// =============================================================
// BARRA DE NAVEGAÇÃO DO CARROSSEL
// =============================================================

class _BarraNavegacaoCarrossel extends StatelessWidget {
  final int indiceAtual;
  final int total;
  final bool temAnterior;
  final bool temProximo;
  final VoidCallback onAnterior;
  final VoidCallback onProximo;

  const _BarraNavegacaoCarrossel({
    required this.indiceAtual,
    required this.total,
    required this.temAnterior,
    required this.temProximo,
    required this.onAnterior,
    required this.onProximo,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // ANTERIOR
        Expanded(
          child: _botaoNav(
            icone: Icons.chevron_left_rounded,
            texto: 'Anterior',
            ativo: temAnterior,
            onTap: onAnterior,
            inverter: false,
          ),
        ),

        // INDICADOR CENTRAL
        Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 7,
          ),
          decoration: BoxDecoration(
            color: TemaHinario.corPrimaria.withValues(
              alpha: 0.08,
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            '${indiceAtual + 1} / $total',
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: TemaHinario.corTexto,
            ),
          ),
        ),

        // PRÓXIMO
        Expanded(
          child: _botaoNav(
            icone: Icons.chevron_right_rounded,
            texto: 'Próximo',
            ativo: temProximo,
            onTap: onProximo,
            inverter: true,
          ),
        ),
      ],
    );
  }

  Widget _botaoNav({
    required IconData icone,
    required String texto,
    required bool ativo,
    required VoidCallback onTap,
    required bool inverter,
  }) {
    final cor = ativo
        ? TemaHinario.corPrimaria
        : TemaHinario.corTextoSecundario.withValues(
            alpha: 0.35,
          );

    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: ativo ? onTap : null,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 8,
          vertical: 8,
        ),
        child: Row(
          mainAxisAlignment: inverter
              ? MainAxisAlignment.end
              : MainAxisAlignment.start,
          children: [
            if (!inverter) Icon(icone, color: cor, size: 22),
            if (!inverter) const SizedBox(width: 2),
            Flexible(
              child: Text(
                texto,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: cor,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            if (inverter) const SizedBox(width: 2),
            if (inverter) Icon(icone, color: cor, size: 22),
          ],
        ),
      ),
    );
  }
}

// =============================================================
// RODAPÉ DA INFORMAÇÃO
// =============================================================

class _RodapeInformacoes extends StatelessWidget {
  const _RodapeInformacoes();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: 18,
      ),
      decoration: BoxDecoration(
        color: TemaHinario.corPrimaria.withValues(
          alpha: 0.06,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: TemaHinario.corPrimaria.withValues(
            alpha: 0.10,
          ),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: TemaHinario.corPrimaria.withValues(
                alpha: 0.10,
              ),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Icon(
              Icons.church_outlined,
              color: TemaHinario.corPrimaria,
              size: 22,
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Text(
              'IECA para Cristo, Cristo para todos.',
              style: TextStyle(
                fontSize: 14,
                height: 1.5,
                fontWeight: FontWeight.w600,
                color: TemaHinario.corTexto,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =============================================================
// ERRO
// =============================================================

class _ErroInformacoes extends StatelessWidget {
  final VoidCallback onTentarNovamente;

  const _ErroInformacoes({
    required this.onTentarNovamente,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: TemaHinario.corPrimaria.withValues(
                  alpha: 0.10,
                ),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.error_outline_rounded,
                size: 38,
                color: TemaHinario.corPrimaria,
              ),
            ),

            const SizedBox(height: 18),

            const Text(
              'Não foi possível carregar as informações da IECA.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: TemaHinario.corTexto,
              ),
            ),

            const SizedBox(height: 8),

            const Text(
              'Verifique os ficheiros de dados e tente novamente.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13,
                height: 1.45,
                color: TemaHinario.corTextoSecundario,
              ),
            ),

            const SizedBox(height: 20),

            FilledButton.icon(
              onPressed: onTentarNovamente,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Tentar novamente'),
              style: FilledButton.styleFrom(
                backgroundColor: TemaHinario.corPrimaria,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 12,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}