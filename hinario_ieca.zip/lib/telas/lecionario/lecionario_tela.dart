import 'package:flutter/material.dart';

import '../../app/tema.dart'; 
import '../../componentes/cabecalho_ieca.dart';
import '../../componentes/navegacao_inferior_ieca.dart';
import '../../modelos/lecionario_modelo.dart';
import '../../servicos/lecionario_servico.dart';
import 'leitura_dia_tela.dart';
import 'sobre_lecionario_tela.dart';

import '../hinario/idiomas_tela.dart';
import '../sobre/sobre_tela.dart';
import '../biblia/biblia_tela.dart';
import '../informacoes_ieca/informacoes_ieca_tela.dart';


class LecionarioScreen extends StatefulWidget {
  const LecionarioScreen({super.key});

  @override
  State<LecionarioScreen> createState() => _LecionarioScreenState();
}

class _LecionarioScreenState extends State<LecionarioScreen>
    with SingleTickerProviderStateMixin {
  /// Lista local dos meses (a tela não depende do serviço para isto).
  static const List<String> _mesesDoAno = [
    'Janeiro',
    'Fevereiro',
    'Março',
    'Abril',
    'Maio',
    'Junho',
    'Julho',
    'Agosto',
    'Setembro',
    'Outubro',
    'Novembro',
    'Dezembro',
  ];

  late final TabController _tabController;

  final LecionarioServico _service = LecionarioServico.instancia;

  @override
  void initState() {
    super.initState();

    final mesAtualIndex = DateTime.now().month - 1;

    _tabController = TabController(
      length: _mesesDoAno.length,
      vsync: this,
      initialIndex: mesAtualIndex.clamp(0, 11),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

 // Item atualmente selecionado no rodapé.
  int _itemSelecionado = 1;

  // =============================================================
  // NAVEGAÇÃO INFERIOR
  // =============================================================

  void _selecionarNavegacao(int indice) {
    if (!mounted) return;

    if (indice == 0) {
      Navigator.of(context).popUntil((route) => route.isFirst);
      return;
    }

    if (indice == 1) {
      setState(() => _itemSelecionado = 1);
      Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (context) => const IdiomasTela(),
        ),
      ).then((_) {
        if (!mounted) return;
        setState(() => _itemSelecionado = 1);
      });
      return;
    }

    if (indice == 2) {
      setState(() => _itemSelecionado = 2);
      Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (context) => const BibliaTela(),
        ),
      ).then((_) {
        if (!mounted) return;
        setState(() => _itemSelecionado = 1);
      });
      return;
    }

    if (indice == 3) {
      setState(() => _itemSelecionado = 3);
      Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (context) => const InformacoesIecaTela(),
        ),
      ).then((_) {
        if (!mounted) return;
        setState(() => _itemSelecionado = 1);
      });
      return;
    }

    if (indice == 4) {
      setState(() => _itemSelecionado = 4);
      Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (context) => const SobreTela(),
        ),
      ).then((_) {
        if (!mounted) return;
        setState(() => _itemSelecionado = 1);
      });
      return;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,

      appBar: CabecalhoIeca(
        titulo: 'Lecionário',
        actions: [
          IconButton(
            tooltip: 'Sobre o Lecionário',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (context) => const SobreLecionarioTela(),
                ),
              );
            },
            icon: const Icon(
              Icons.info_outline_rounded,
              color: TemaHinario.corTexto,
              size: 22,
            ),
          ),
        ],
      ),

      body: Column(
        children: [
          // =============================================
          // VERSÍCULO DO ANO 2026
          // =============================================
          const _VersiculoDoAno(),

          // =============================================
          // ABAS DOS MESES
          // =============================================
          Container(
            height: 48,
            decoration: BoxDecoration(
              color: colorScheme.surface,
              border: Border(
                bottom: BorderSide(
                  color: colorScheme.outlineVariant,
                  width: 0.6,
                ),
              ),
            ),
            child: TabBar(
              controller: _tabController,
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              labelColor: colorScheme.primary,
              unselectedLabelColor: colorScheme.onSurfaceVariant,
              indicatorColor: colorScheme.primary,
              indicatorWeight: 3,
              dividerColor: Colors.transparent,
              labelStyle: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
              ),
              unselectedLabelStyle: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 8),
              tabs: _mesesDoAno
                  .map(
                    (mes) => Tab(
                      text: mes,
                    ),
                  )
                  .toList(),
            ),
          ),

          // =============================================
          // CONTEÚDO DO MÊS
          // =============================================
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: _mesesDoAno
                  .asMap()
                  .entries
                  .map(
                    (entry) => _ConteudoMesView(
                      numeroMes: entry.key + 1,
                      nomeMes: entry.value,
                      service: _service,
                    ),
                  )
                  .toList(),
            ),
          ),
        ],
      ),

      bottomNavigationBar: NavegacaoInferiorIeca(
        indiceSelecionado: 1,
        onDestinationSelected: _selecionarNavegacao,
      ),
    );
  }
}

// =================================================================
// VERSÍCULO DO ANO
// =================================================================

class _VersiculoDoAno extends StatelessWidget {
  const _VersiculoDoAno();

  static const String _texto =
      'Deixemos todo o embaraço, e o pecado, e corramos, '
      'com paciência, olhando para Jesus.';

  static const String _referencia = 'Hebreus 12:1b-2a';

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 6),
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            colorScheme.primary.withOpacity(0.10),
            colorScheme.primary.withOpacity(0.03),
          ],
        ),
        border: Border.all(
          color: colorScheme.primary.withOpacity(0.18),
          width: 0.8,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: colorScheme.primary.withOpacity(0.14),
              borderRadius: BorderRadius.circular(10),
            ),
            alignment: Alignment.center,
            child: Icon(
              Icons.format_quote_rounded,
              size: 18,
              color: colorScheme.primary,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'TEMA DO ANO 2026',
                  style: TextStyle(
                    color: colorScheme.primary,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.8,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '“$_texto”',
                  style: TextStyle(
                    color: colorScheme.onSurface,
                    fontSize: 13,
                    height: 1.45,
                    fontStyle: FontStyle.italic,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _referencia,
                  style: TextStyle(
                    color: colorScheme.onSurfaceVariant,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// =================================================================
// CONTEÚDO DO MÊS
// =================================================================

class _ConteudoMesView extends StatelessWidget {
  final int numeroMes;
  final String nomeMes;
  final LecionarioServico service;

  const _ConteudoMesView({
    required this.numeroMes,
    required this.nomeMes,
    required this.service,
  });

  /// Calcula o índice (base 1) da semana atual dentro do mês.
  int _calcularSemanaAtual() {
    final dia = DateTime.now().day;
    return ((dia - 1) ~/ 7) + 1;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<LecionarioMes?>(
      future: service.obterMes(numeroMes),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _EstadoCarregamento();
        }

        if (snapshot.hasError) {
          return _EstadoErro(
            mes: nomeMes,
            erro: snapshot.error,
          );
        }

        final dados = snapshot.data;

        if (dados == null) {
          return _EstadoErro(
            mes: nomeMes,
          );
        }

        final agora = DateTime.now();
        final isMesAtual = numeroMes == agora.month;
        final semanaAtual = isMesAtual ? _calcularSemanaAtual() : 1;

        return RefreshIndicator(
          onRefresh: () async {
            service.limparCache();
          },
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            padding: const EdgeInsets.fromLTRB(
              16,
              16,
              16,
              32,
            ),
            children: [
              _CabecalhoMes(
                dados: dados,
              ),
              const SizedBox(height: 20),
              const _TituloSecao(
                titulo: 'Semanas',
                icone: Icons.calendar_month_outlined,
              ),
              const SizedBox(height: 10),
              ...dados.semanas.asMap().entries.map(
                    (entry) => _CardSemana(
                      semana: entry.value,
                      numeroSemana: entry.key + 1,
                      nomeMes: nomeMes,
                      ano: dados.ano,
                      semanaAtual: semanaAtual,
                    ),
                  ),
            ],
          ),
        );
      },
    );
  }
}

// =================================================================
// CABEÇALHO DO MÊS
// =================================================================

class _CabecalhoMes extends StatelessWidget {
  final LecionarioMes dados;

  const _CabecalhoMes({
    required this.dados,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            colorScheme.primary,
            colorScheme.primaryContainer,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: colorScheme.primary.withOpacity(0.12),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.16),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.menu_book_rounded,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    dados.mes,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                Text(
                  dados.ano.toString(),
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.82),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Text(
              'Tema do mês',
              style: TextStyle(
                color: Colors.white.withOpacity(0.78),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              dados.temaMensal,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                height: 1.3,
                fontWeight: FontWeight.w800,
              ),
            ),
            if (dados.introducaoMensal.trim().isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(
                dados.introducaoMensal,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.88),
                  fontSize: 13,
                  height: 1.55,
                ),
              ),
            ],
            if (dados.datasImportantes.isNotEmpty) ...[
              const SizedBox(height: 18),
              Divider(
                color: Colors.white.withOpacity(0.20),
                height: 1,
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Icon(
                    Icons.event_note_outlined,
                    size: 17,
                    color: Colors.white.withOpacity(0.90),
                  ),
                  const SizedBox(width: 7),
                  const Text(
                    'Datas importantes',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              ...dados.datasImportantes.map(
                (data) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        data.data,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.78),
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          data.evento,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// =================================================================
// TÍTULO DE SECÇÃO
// =================================================================

class _TituloSecao extends StatelessWidget {
  final String titulo;
  final IconData icone;

  const _TituloSecao({
    required this.titulo,
    required this.icone,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Row(
      children: [
        Icon(
          icone,
          size: 20,
          color: colorScheme.primary,
        ),
        const SizedBox(width: 8),
        Text(
          titulo,
          style: TextStyle(
            color: colorScheme.onSurface,
            fontSize: 16,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

// =================================================================
// CARD DA SEMANA
// =================================================================

class _CardSemana extends StatelessWidget {
  final Semana semana;
  final int numeroSemana;
  final String nomeMes;
  final int ano;
  final int semanaAtual;

  const _CardSemana({
    required this.semana,
    required this.numeroSemana,
    required this.nomeMes,
    required this.ano,
    required this.semanaAtual,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final isSemanaAtual = numeroSemana == semanaAtual;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isSemanaAtual
              ? colorScheme.primary
              : colorScheme.outlineVariant,
          width: isSemanaAtual ? 1.6 : 0.8,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.035),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Theme(
        data: theme.copyWith(
          dividerColor: Colors.transparent,
        ),
        child: ExpansionTile(
          initiallyExpanded: isSemanaAtual || numeroSemana == 1,
          tilePadding: const EdgeInsets.fromLTRB(
            16,
            8,
            12,
            8,
          ),
          childrenPadding: const EdgeInsets.only(
            bottom: 6,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          collapsedShape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          iconColor: colorScheme.primary,
          collapsedIconColor: colorScheme.onSurfaceVariant,
          leading: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: isSemanaAtual
                  ? colorScheme.primary
                  : colorScheme.primary.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            alignment: Alignment.center,
            child: Text(
              '$numeroSemana',
              style: TextStyle(
                color: isSemanaAtual
                    ? Colors.white
                    : colorScheme.primary,
                fontSize: 15,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          title: Row(
            children: [
              Expanded(
                child: Text(
                  semana.periodo,
                  style: TextStyle(
                    color: colorScheme.onSurface,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              if (isSemanaAtual)
                Container(
                  margin: const EdgeInsets.only(left: 6),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: colorScheme.primary.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(7),
                  ),
                  child: Text(
                    'ESTA SEMANA',
                    style: TextStyle(
                      color: colorScheme.primary,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.4,
                    ),
                  ),
                ),
            ],
          ),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              semana.temaSemanal,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: colorScheme.onSurfaceVariant,
                fontSize: 12,
                height: 1.35,
              ),
            ),
          ),
          children: [
            if (semana.introducaoSemanal != null &&
                semana.introducaoSemanal!.trim().isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  16,
                  0,
                  16,
                  12,
                ),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: colorScheme.surfaceContainerHighest
                        .withOpacity(0.45),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    semana.introducaoSemanal!,
                    style: TextStyle(
                      color: colorScheme.onSurfaceVariant,
                      fontSize: 12,
                      height: 1.5,
                    ),
                  ),
                ),
              ),
            ...semana.dias.map(
              (dia) => _ItemDiaLecionario(
                dia: dia,
                nomeMes: nomeMes,
                ano: ano,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// =================================================================
// ITEM DO DIA
// =================================================================

class _ItemDiaLecionario extends StatelessWidget {
  final DiaLecionario dia;
  final String nomeMes;
  final int ano;

  const _ItemDiaLecionario({
    required this.dia,
    required this.nomeMes,
    required this.ano,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    final destaque = dia.isDomingo;
    final possuiLeituras = _possuiLeituras(dia);
    final possuiLiturgia = dia.liturgia != null;
    final possuiPalavras = _possuiPalavras(dia);

    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute<void>(
            builder: (context) => LeituraDiaTela(
              dia: dia,
              mes: nomeMes,
              ano: ano,
            ),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(
          horizontal: 10,
          vertical: 2,
        ),
        padding: const EdgeInsets.fromLTRB(
          10,
          12,
          10,
          12,
        ),
        decoration: BoxDecoration(
          color: destaque
              ? colorScheme.primary.withOpacity(0.045)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _MarcadorDia(
              data: dia.data,
              destaque: destaque,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (dia.evento != null &&
                      dia.evento!.trim().isNotEmpty) ...[
                    _EtiquetaEvento(
                      texto: dia.evento!,
                    ),
                    const SizedBox(height: 5),
                  ],
                  Text(
                    dia.titulo,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: colorScheme.onSurface,
                      fontSize: 14,
                      height: 1.3,
                      fontWeight: destaque
                          ? FontWeight.w800
                          : FontWeight.w700,
                    ),
                  ),
                  if (_possuiReferenciaPrincipal(dia)) ...[
                    const SizedBox(height: 5),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.menu_book_outlined,
                          size: 15,
                          color: colorScheme.primary,
                        ),
                        const SizedBox(width: 5),
                        Expanded(
                          child: Text(
                            _referenciasPrincipais(dia),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: colorScheme.primary,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                  const SizedBox(height: 6),
                  Text(
                    dia.reflexao,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: colorScheme.onSurfaceVariant,
                      fontSize: 12,
                      height: 1.45,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 5,
                    children: [
                      if (possuiLeituras)
                        const _Indicador(
                          icone: Icons.menu_book_outlined,
                          texto: 'Leituras',
                        ),
                      if (possuiLiturgia)
                        const _Indicador(
                          icone: Icons.church_outlined,
                          texto: 'Liturgia',
                        ),
                      if (possuiPalavras)
                        const _Indicador(
                          icone: Icons.record_voice_over_outlined,
                          texto: '7 Palavras',
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 4),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Icon(
                Icons.chevron_right_rounded,
                size: 20,
                color: colorScheme.onSurfaceVariant.withOpacity(0.6),
              ),
            ),
          ],
        ),
      ),
    );
  }

  bool _possuiLeituras(DiaLecionario dia) {
    return (dia.textoBiblico != null &&
            dia.textoBiblico!.trim().isNotEmpty) ||
        dia.textosBiblicos.isNotEmpty ||
        (dia.liturgia != null &&
            dia.liturgia!.leiturasBiblicas.isNotEmpty);
  }

  bool _possuiReferenciaPrincipal(DiaLecionario dia) {
    return (dia.textoBiblico != null &&
            dia.textoBiblico!.trim().isNotEmpty) ||
        dia.textosBiblicos.isNotEmpty;
  }

  String _referenciasPrincipais(DiaLecionario dia) {
    if (dia.textoBiblico != null &&
        dia.textoBiblico!.trim().isNotEmpty) {
      return dia.textoBiblico!;
    }

    return dia.textosBiblicos.join(' • ');
  }

  bool _possuiPalavras(DiaLecionario dia) {
    return dia.palavras.isNotEmpty;
  }
}

// =================================================================
// MARCADOR DO DIA
// =================================================================

class _MarcadorDia extends StatelessWidget {
  final String data;
  final bool destaque;

  const _MarcadorDia({
    required this.data,
    required this.destaque,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      width: 50,
      padding: const EdgeInsets.symmetric(
        horizontal: 5,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: destaque
            ? colorScheme.primary
            : colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(11),
      ),
      child: Text(
        data,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: destaque
              ? Colors.white
              : colorScheme.onSurfaceVariant,
          fontSize: 10,
          height: 1.2,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

// =================================================================
// ETIQUETA DE EVENTO
// =================================================================

class _EtiquetaEvento extends StatelessWidget {
  final String texto;

  const _EtiquetaEvento({
    required this.texto,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 7,
        vertical: 3,
      ),
      decoration: BoxDecoration(
        color: colorScheme.secondaryContainer,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        texto,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: colorScheme.onSecondaryContainer,
          fontSize: 9.5,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

// =================================================================
// INDICADOR
// =================================================================

class _Indicador extends StatelessWidget {
  final IconData icone;
  final String texto;

  const _Indicador({
    required this.icone,
    required this.texto,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 7,
        vertical: 4,
      ),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest.withOpacity(0.55),
        borderRadius: BorderRadius.circular(7),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icone,
            size: 12,
            color: colorScheme.onSurfaceVariant,
          ),
          const SizedBox(width: 4),
          Text(
            texto,
            style: TextStyle(
              color: colorScheme.onSurfaceVariant,
              fontSize: 9.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// =================================================================
// ESTADO DE CARREGAMENTO
// =================================================================

class _EstadoCarregamento extends StatelessWidget {
  const _EstadoCarregamento();

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 30,
            height: 30,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              color: colorScheme.primary,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'A carregar o lecionário...',
            style: TextStyle(
              color: colorScheme.onSurfaceVariant,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }
}

// =================================================================
// ESTADO DE ERRO
// =================================================================

class _EstadoErro extends StatelessWidget {
  final String mes;
  final Object? erro;

  const _EstadoErro({
    required this.mes,
    this.erro,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: colorScheme.errorContainer,
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.menu_book_outlined,
                size: 30,
                color: colorScheme.onErrorContainer,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Não foi possível carregar o lecionário',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: colorScheme.onSurface,
                fontSize: 16,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Verifica os dados do mês de $mes e tenta novamente.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: colorScheme.onSurfaceVariant,
                fontSize: 13,
                height: 1.4,
              ),
            ),
            if (erro != null) ...[
              const SizedBox(height: 10),
              Text(
                erro.toString(),
                textAlign: TextAlign.center,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: colorScheme.error,
                  fontSize: 10,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}