import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/tema.dart';
import '../../componentes/cabecalho_ieca.dart';
import '../../componentes/navegacao_inferior_ieca.dart';
import '../../modelos/lecionario_modelo.dart';
import '../../servicos/constancia_servico.dart';
import '../../componentes/quadra_liturgica.dart';

import '../hinario/idiomas_tela.dart';
import '../sobre/sobre_tela.dart';
import '../biblia/biblia_tela.dart';
import '../informacoes_ieca/informacoes_ieca_tela.dart';

class LeituraDiaTela extends StatefulWidget {
  final DiaLecionario dia;
  final String mes;
  final int ano;

  const LeituraDiaTela({
    super.key,
    required this.dia,
    required this.mes,
    required this.ano,
  });

  @override
  State<LeituraDiaTela> createState() => _LeituraDiaTelaState();
}

class _LeituraDiaTelaState extends State<LeituraDiaTela> {
  DiaLecionario get dia => widget.dia;
  String get mes => widget.mes;
  int get ano => widget.ano;

  int _itemSelecionado = 1;

  @override
  void initState() {
    super.initState();
    _registarConstancia();
  }

  /// Regista automaticamente a leitura do dia na constância do Lecionário.
  Future<void> _registarConstancia() async {
    await ConstanciaServico.instancia.registrarUsoLecionario();
  }

  // =============================================================
  // NAVEGAÇÃO INFERIOR
  // =============================================================
  void _selecionarNavegacao(int indice) {
    if (!mounted) return;

    if (indice == 0) {
      Navigator.of(context).popUntil((route) => route.isFirst);
      return;
    }

    if (indice == 1) {
      setState(() => _itemSelecionado = 1);
      Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (context) => const IdiomasTela(),
        ),
      ).then((_) {
        if (!mounted) return;
        setState(() => _itemSelecionado = 1);
      });
      return;
    }

    if (indice == 2) {
      setState(() => _itemSelecionado = 2);
      Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (context) => const BibliaTela(),
        ),
      ).then((_) {
        if (!mounted) return;
        setState(() => _itemSelecionado = 1);
      });
      return;
    }

    if (indice == 3) {
      setState(() => _itemSelecionado = 3);
      Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (context) => const InformacoesIecaTela(),
        ),
      ).then((_) {
        if (!mounted) return;
        setState(() => _itemSelecionado = 1);
      });
      return;
    }

    if (indice == 4) {
      setState(() => _itemSelecionado = 4);
      Navigator.push(
        context,
        MaterialPageRoute<void>(
          builder: (context) => const SobreTela(),
        ),
      ).then((_) {
        if (!mounted) return;
        setState(() => _itemSelecionado = 1);
      });
      return;
    }
  }

  // =============================================================
  // BUILD
  // =============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TemaHinario.corSuperficie,
      appBar: const CabecalhoIeca(),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 40),
        children: [
          _CabecalhoDia(dia: dia, mes: mes, ano: ano),

          if (dia.referenciasBiblicas.isNotEmpty) ...[
            const SizedBox(height: 24),
            const _SecaoTitulo(
              icone: Icons.menu_book_outlined,
              titulo: 'Referências Bíblicas',
            ),
            const SizedBox(height: 10),
            ...dia.referenciasBiblicas.map(
              (ref) => _CartaoReferencia(texto: ref),
            ),
          ],

          if (dia.reflexao.trim().isNotEmpty) ...[
            const SizedBox(height: 24),
            const _SecaoTitulo(
              icone: Icons.lightbulb_outline_rounded,
              titulo: 'Reflexão',
            ),
            const SizedBox(height: 10),
            _CartaoTexto(texto: dia.reflexao, italico: false),
          ],

          if (dia.liturgia != null) ...[
            const SizedBox(height: 24),
            const _SecaoTitulo(
              icone: Icons.church_outlined,
              titulo: 'Liturgia',
            ),
            const SizedBox(height: 10),
            _CartaoLiturgia(liturgia: dia.liturgia!),
          ],

          if (dia.palavras.isNotEmpty) ...[
            const SizedBox(height: 24),
            const _SecaoTitulo(
              icone: Icons.record_voice_over_outlined,
              titulo: 'As 7 Palavras de Cristo',
            ),
            const SizedBox(height: 10),
            ..._construirPalavrasOrdenadas(),
          ],

          const SizedBox(height: 8),
          _BotaoCopiar(onPressed: () => _copiarDia(context)),
        ],
      ),
      bottomNavigationBar: NavegacaoInferiorIeca(
        indiceSelecionado: _itemSelecionado,
        onDestinationSelected: _selecionarNavegacao,
      ),
    );
  }

  List<Widget> _construirPalavrasOrdenadas() {
    final palavras = [...dia.palavras]
      ..sort((a, b) => a.ordem.compareTo(b.ordem));

    return palavras
        .map((palavra) => _CartaoPalavra(palavra: palavra))
        .toList();
  }

  Future<void> _copiarDia(BuildContext context) async {
    final buffer = StringBuffer()
      ..writeln(dia.data)
      ..writeln(dia.titulo)
      ..writeln();

    if (dia.referenciasBiblicas.isNotEmpty) {
      buffer.writeln('REFERÊNCIAS BÍBLICAS');
      for (final ref in dia.referenciasBiblicas) {
        buffer.writeln('• $ref');
      }
      buffer.writeln();
    }

    if (dia.reflexao.trim().isNotEmpty) {
      buffer.writeln('REFLEXÃO');
      buffer.writeln(dia.reflexao);
      buffer.writeln();
    }

    if (dia.liturgia != null) {
      final liturgia = dia.liturgia!;
      buffer.writeln('LITURGIA');

      if (liturgia.hinos.isNotEmpty) {
        buffer.writeln('Hinos: ${liturgia.hinos.join(', ')}');
      }
      if (liturgia.possuiSalmo) {
        buffer.writeln('Salmo: ${liturgia.salmo}');
      }
      if (liturgia.leiturasBiblicas.isNotEmpty) {
        buffer.writeln(
          'Leituras: ${liturgia.leiturasBiblicas.join(', ')}',
        );
      }
      buffer.writeln();
    }

    if (dia.palavras.isNotEmpty) {
      buffer.writeln('AS 7 PALAVRAS DE CRISTO');
      final palavras = [...dia.palavras]
        ..sort((a, b) => a.ordem.compareTo(b.ordem));

      for (final palavra in palavras) {
        buffer
          ..writeln('${palavra.ordem}. ${palavra.palavra}')
          ..writeln(palavra.texto)
          ..writeln(palavra.meditacao)
          ..writeln();
      }
    }

    await Clipboard.setData(
      ClipboardData(text: buffer.toString().trim()),
    );

    if (!context.mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Dia copiado para a área de transferência.'),
        duration: Duration(milliseconds: 1400),
      ),
    );
  }
}

// =================================================================
// CABEÇALHO DO DIA
// =================================================================

class _CabecalhoDia extends StatelessWidget {
  final DiaLecionario dia;
  final String mes;
  final int ano;

  const _CabecalhoDia({
    required this.dia,
    required this.mes,
    required this.ano,
  });

  @override
  Widget build(BuildContext context) {
    final destaque = dia.isDomingo;

    final corFundo1 = destaque
        ? TemaHinario.corPrimaria
        : TemaHinario.corPrimaria.withValues(alpha: 0.08);

    final corFundo2 = destaque
        ? TemaHinario.corPrimariaContainer
        : TemaHinario.corSuperficieAlta;

    final corTextoPrincipal =
        destaque ? Colors.white : TemaHinario.corTexto;

    final corTextoSec = destaque
        ? Colors.white.withValues(alpha: 0.85)
        : TemaHinario.corTextoSecundario;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [corFundo1, corFundo2],
        ),
        boxShadow: [
          BoxShadow(
            color: TemaHinario.corPrimaria.withValues(alpha: 0.18),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: destaque
                      ? Colors.white.withValues(alpha: 0.18)
                      : TemaHinario.corPrimaria.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(14),
                ),
                alignment: Alignment.center,
                child: Icon(
                  destaque
                      ? Icons.church_rounded
                      : Icons.calendar_today_rounded,
                  color: destaque
                      ? Colors.white
                      : TemaHinario.corPrimaria,
                  size: 22,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$mes • $ano',
                      style: TextStyle(
                        color: corTextoSec,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      dia.data,
                      style: TextStyle(
                        color: corTextoPrincipal,
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
              _BadgeQuadra(data: dia.data),
            ],
          ),
          const SizedBox(height: 20),
          Text(
            dia.titulo,
            style: TextStyle(
              color: corTextoPrincipal,
              fontSize: 22,
              height: 1.3,
              fontWeight: FontWeight.w800,
            ),
          ),
          if (dia.evento != null &&
              dia.evento!.trim().isNotEmpty &&
              dia.evento != dia.titulo) ...[
            const SizedBox(height: 8),
            Text(
              dia.evento!,
              style: TextStyle(
                color: corTextoSec,
                fontSize: 13.5,
                height: 1.4,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// =================================================================
// BADGE DE QUADRA LITÚRGICA
// =================================================================

class _BadgeQuadra extends StatelessWidget {
  final String data;

  const _BadgeQuadra({required this.data});

  DateTime _extrairDataOuHoje(String texto) {
    final regex = RegExp(
      r'(\d{1,2})\s+de\s+([A-Za-zÀ-ÿ]+)\s+de\s+(\d{4})',
      caseSensitive: false,
    );
    final match = regex.firstMatch(texto);
    if (match == null) return DateTime.now();

    final dia = int.tryParse(match.group(1)!) ?? 1;
    final nomeMes = match.group(2)!.toLowerCase();
    final ano = int.tryParse(match.group(3)!) ?? 2026;

    const meses = {
      'janeiro': 1,
      'fevereiro': 2,
      'março': 3,
      'marco': 3,
      'abril': 4,
      'maio': 5,
      'junho': 6,
      'julho': 7,
      'agosto': 8,
      'setembro': 9,
      'outubro': 10,
      'novembro': 11,
      'dezembro': 12,
    };

    final m = meses[nomeMes] ?? 1;
    return DateTime(ano, m, dia);
  }

  @override
  Widget build(BuildContext context) {
    final quadra = QuadraLiturgica.paraData(_extrairDataOuHoje(data));
    final cor = Color(quadra.corArgb);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: cor.withOpacity(0.14),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(
          color: cor.withOpacity(0.35),
          width: 0.8,
        ),
      ),
      child: Text(
        quadra.nome.toUpperCase(),
        style: TextStyle(
          color: cor,
          fontSize: 9.5,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

// =================================================================
// TÍTULO DE SECÇÃO
// =================================================================

class _SecaoTitulo extends StatelessWidget {
  final IconData icone;
  final String titulo;

  const _SecaoTitulo({
    required this.icone,
    required this.titulo,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: TemaHinario.corPrimaria.withOpacity(0.10),
            borderRadius: BorderRadius.circular(10),
          ),
          alignment: Alignment.center,
          child: Icon(
            icone,
            size: 18,
            color: TemaHinario.corPrimaria,
          ),
        ),
        const SizedBox(width: 10),
        Text(
          titulo,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: TemaHinario.corTexto,
          ),
        ),
      ],
    );
  }
}

// =================================================================
// CARTÃO DE REFERÊNCIA BÍBLICA
// =================================================================

class _CartaoReferencia extends StatelessWidget {
  final String texto;

  const _CartaoReferencia({required this.texto});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: TemaHinario.corSuperficieAlta,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: TemaHinario.corPrimaria.withOpacity(0.25),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: TemaHinario.corPrimaria.withOpacity(0.12),
              borderRadius: BorderRadius.circular(9),
            ),
            alignment: Alignment.center,
            child: const Icon(
              Icons.menu_book_rounded,
              size: 16,
              color: TemaHinario.corPrimaria,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              texto,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: TemaHinario.corPrimaria,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// =================================================================
// CARTÃO DE TEXTO GENÉRICO
// =================================================================

class _CartaoTexto extends StatelessWidget {
  final String texto;
  final bool italico;

  const _CartaoTexto({
    required this.texto,
    this.italico = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: TemaHinario.corSuperficieAlta,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0A000000),
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Text(
        texto,
        style: TextStyle(
          fontSize: 15,
          height: 1.65,
          fontStyle: italico ? FontStyle.italic : FontStyle.normal,
          color: TemaHinario.corTexto,
        ),
      ),
    );
  }
}

// =================================================================
// CARTÃO DE LITURGIA
// =================================================================

class _CartaoLiturgia extends StatelessWidget {
  final Liturgia liturgia;

  const _CartaoLiturgia({required this.liturgia});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: TemaHinario.corSuperficieAlta,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: TemaHinario.corPrimaria.withOpacity(0.10),
          width: 0.8,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0A000000),
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (liturgia.hinos.isNotEmpty) ...[
            const _LinhaRotulo(
              icone: Icons.music_note_rounded,
              texto: 'Hinos',
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children:
                  liturgia.hinos.map((h) => _Etiqueta(texto: h)).toList(),
            ),
            const SizedBox(height: 18),
          ],
          if (liturgia.possuiSalmo) ...[
            const _LinhaRotulo(
              icone: Icons.format_quote_rounded,
              texto: 'Salmo',
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color:
                    TemaHinario.corSuperficieMedia.withOpacity(0.6),
                borderRadius: BorderRadius.circular(12),
                border: Border(
                  left: BorderSide(
                    color: TemaHinario.corPrimaria,
                    width: 3,
                  ),
                ),
              ),
              child: Text(
                liturgia.salmo!,
                style: const TextStyle(
                  fontSize: 15,
                  height: 1.6,
                  fontStyle: FontStyle.italic,
                  color: TemaHinario.corTexto,
                ),
              ),
            ),
            const SizedBox(height: 18),
          ],
          if (liturgia.leiturasBiblicas.isNotEmpty) ...[
            const _LinhaRotulo(
              icone: Icons.menu_book_outlined,
              texto: 'Leituras Bíblicas',
            ),
            const SizedBox(height: 8),
            ...liturgia.leiturasBiblicas.map(
              (leitura) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 7),
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: TemaHinario.corPrimaria,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        leitura,
                        style: const TextStyle(
                          fontSize: 14,
                          height: 1.5,
                          color: TemaHinario.corTexto,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// =================================================================
// CARTÃO DAS 7 PALAVRAS
// =================================================================

class _CartaoPalavra extends StatelessWidget {
  final PalavraCristo palavra;

  const _CartaoPalavra({required this.palavra});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: TemaHinario.corSuperficieAlta,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: TemaHinario.corPrimaria.withOpacity(0.20),
          width: 1,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0A000000),
            blurRadius: 10,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      TemaHinario.corPrimaria,
                      TemaHinario.corPrimariaContainer,
                    ],
                  ),
                ),
                alignment: Alignment.center,
                child: Text(
                  '${palavra.ordem}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  palavra.palavra,
                  style: const TextStyle(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w800,
                    color: TemaHinario.corTexto,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            palavra.texto,
            style: const TextStyle(
              fontSize: 15.5,
              height: 1.65,
              fontStyle: FontStyle.italic,
              color: TemaHinario.corTexto,
            ),
          ),
          if (palavra.meditacao.trim().isNotEmpty) ...[
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: TemaHinario.corSuperficieMedia,
                borderRadius: BorderRadius.circular(14),
                border: Border(
                  left: BorderSide(
                    color: TemaHinario.corPrimaria,
                    width: 3,
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _LinhaRotulo(
                    icone: Icons.lightbulb_outline_rounded,
                    texto: 'Meditação',
                  ),
                  const SizedBox(height: 8),
                  Text(
                    palavra.meditacao,
                    style: const TextStyle(
                      fontSize: 14.5,
                      height: 1.6,
                      color: TemaHinario.corTexto,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// =================================================================
// LINHA DE RÓTULO
// =================================================================

class _LinhaRotulo extends StatelessWidget {
  final IconData icone;
  final String texto;

  const _LinhaRotulo({
    required this.icone,
    required this.texto,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icone, size: 15, color: TemaHinario.corPrimaria),
        const SizedBox(width: 6),
        Text(
          texto,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.6,
            color: TemaHinario.corPrimaria,
          ),
        ),
      ],
    );
  }
}

// =================================================================
// ETIQUETA
// =================================================================

class _Etiqueta extends StatelessWidget {
  final String texto;

  const _Etiqueta({required this.texto});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: TemaHinario.corPrimaria.withOpacity(0.10),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: TemaHinario.corPrimaria.withOpacity(0.20),
          width: 0.6,
        ),
      ),
      child: Text(
        texto,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w700,
          color: TemaHinario.corPrimaria,
        ),
      ),
    );
  }
}

// =================================================================
// BOTÃO COPIAR
// =================================================================

class _BotaoCopiar extends StatelessWidget {
  final VoidCallback onPressed;

  const _BotaoCopiar({required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onPressed,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: TemaHinario.corPrimaria,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: TemaHinario.corPrimaria.withOpacity(0.25),
                blurRadius: 14,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.copy_rounded,
                size: 18,
                color: Colors.white,
              ),
              SizedBox(width: 8),
              Text(
                'Copiar leitura do dia',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}