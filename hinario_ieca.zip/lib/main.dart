import 'dart:async';

import 'package:flutter/material.dart';

import 'app/app.dart';
import 'servicos/notificacoes_servico.dart';

Future<void> main() async {
  // -------------------------------------------------------------
  // GARANTIR QUE O BINDING ESTÁ PRONTO
  // -------------------------------------------------------------
  //
  // Esta é a única operação que precisa de ser feita antes
  // do runApp. É muito rápida.
  //

  WidgetsFlutterBinding.ensureInitialized();

  // -------------------------------------------------------------
  // INICIAR A APLICAÇÃO IMEDIATAMENTE
  // -------------------------------------------------------------
  //
  // runApp() é chamado o mais cedo possível para que a Splash
  // apareça ao utilizador sem qualquer atraso.
  //

  runApp(
    const HinarioApp(),
  );

  // -------------------------------------------------------------
  // TRABALHO EM SEGUNDO PLANO
  // -------------------------------------------------------------
  //
  // Tudo o que é pesado (notificações, agendamentos, I/O de
  // assets) fica fora do caminho crítico de arranque.
  //
  // Só é executado depois do primeiro frame ser desenhado,
  // para não competir com a renderização da Splash.
  //

  WidgetsBinding.instance.addPostFrameCallback((_) {
    unawaited(
      _inicializarServicosEmSegundoPlano(),
    );
  });
}

/// ===============================================================
/// INICIALIZAÇÃO DOS SERVIÇOS EM SEGUNDO PLANO
/// ===============================================================
///
/// Este método só é executado depois do primeiro frame da UI
/// estar desenhado, o que garante que a aplicação fica
/// imediatamente responsiva para o utilizador.
///
/// Cada passo está isolado num try/catch próprio para que um
/// problema não impeça os restantes de correr.
///
/// ===============================================================

Future<void> _inicializarServicosEmSegundoPlano() async {
  debugPrint('▶️ A iniciar serviços em segundo plano...');

  final NotificacoesServico servico =
      NotificacoesServico.instancia;

  // -------------------------------------------------------------
  // 1) INICIALIZAR O PLUGIN
  // -------------------------------------------------------------

  try {
    debugPrint('   → Passo 1: inicializar()');
    await servico.inicializar();
    debugPrint('   ✅ inicializar() concluído');
  } catch (e, stackTrace) {
    debugPrint('   ❌ Falha ao inicializar: $e');
    debugPrint('$stackTrace');
    return;
  }

  // -------------------------------------------------------------
  // 2) PERMISSÕES
  // -------------------------------------------------------------

  try {
    debugPrint('   → Passo 2: solicitarPermissoes()');
    await servico.solicitarPermissoes();
    debugPrint('   ✅ solicitarPermissoes() concluído');
  } catch (e) {
    debugPrint('   ❌ Erro em solicitarPermissoes: $e');
  }

  // -------------------------------------------------------------
  // 3) NOTIFICAÇÕES DIÁRIAS
  // -------------------------------------------------------------

  try {
    debugPrint('   → Passo 3: configurarNotificacoesDiarias()');
    await servico.configurarNotificacoesDiarias();
    debugPrint('   ✅ configurarNotificacoesDiarias() concluído');
  } catch (e) {
    debugPrint('   ❌ Erro em configurarNotificacoesDiarias: $e');
  }

  // -------------------------------------------------------------
  // 4) SABIAS QUE?
  // -------------------------------------------------------------

  try {
    debugPrint('   → Passo 4: configurarNotificacaoSabiasQue()');
    await servico.configurarNotificacaoSabiasQue();
    debugPrint('   ✅ configurarNotificacaoSabiasQue() concluído');
  } catch (e) {
    debugPrint('   ❌ Erro em configurarNotificacaoSabiasQue: $e');
  }

  // -------------------------------------------------------------
  // 5) NOTIFICAÇÕES INICIAIS
  // -------------------------------------------------------------

  try {
    debugPrint('   → Passo 5: enviarNotificacoesIniciais()');
    await servico.enviarNotificacoesIniciais();
    debugPrint('   ✅ enviarNotificacoesIniciais() concluído');
  } catch (e) {
    debugPrint('   ❌ Erro em enviarNotificacoesIniciais: $e');
  }

  // -------------------------------------------------------------
  // 6) PROCESSAR NOTIFICAÇÃO QUE ABRIU A APP
  // -------------------------------------------------------------

  try {
    debugPrint('   → Passo 6: processarNotificacaoQueAbriuAplicacao()');
    await servico.processarNotificacaoQueAbriuAplicacao();
    debugPrint('   ✅ processarNotificacaoQueAbriuAplicacao() concluído');
  } catch (e) {
    debugPrint('   ❌ Erro em processarNotificacaoQueAbriuAplicacao: $e');
  }

  debugPrint('🏁 Serviços em segundo plano concluídos.');
}